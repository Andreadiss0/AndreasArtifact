#!/bin/bash
# System monitor (logs to /tmp/monitor.log).
source /opt/ros/foxy/setup.bash
source ~/sim_ws/install/setup.bash
source ~/monitor_ws_v2/install/setup.bash
export ROS_DOMAIN_ID=0
export ROS_LOCALHOST_ONLY=0

# SROS2 creds for /bridge enclave (trusted observer).
if [ "${USE_SROS2:-1}" = "1" ]; then
    export ROS_SECURITY_ENABLE=true
    export ROS_SECURITY_STRATEGY=Enforce
    export ROS_SECURITY_KEYSTORE=/home/f1tenth/sros2_keystore_f1tenth
    export ROS_SECURITY_ENCLAVE_OVERRIDE=/bridge
fi

# Force FastRTPS to UDPv4-only so tc netem rules on lo apply.
export FASTRTPS_DEFAULT_PROFILES_FILE=/home/f1tenth/udp_only.xml

ros2 run system_monitor_v2 system_monitor_node 2>&1 | tee /tmp/monitor.log
