#!/bin/bash
# Alerts viewer (RELIABLE QoS subscriber for /monitor_alerts).
source /opt/ros/foxy/setup.bash
source ~/sim_ws/install/setup.bash 2>/dev/null
export ROS_DOMAIN_ID=0
export ROS_LOCALHOST_ONLY=0

# SROS2 creds required to receive secured /monitor_alerts.
if [ "${USE_SROS2:-1}" = "1" ]; then
    export ROS_SECURITY_ENABLE=true
    export ROS_SECURITY_STRATEGY=Enforce
    export ROS_SECURITY_KEYSTORE=/home/f1tenth/sros2_keystore_f1tenth
    export ROS_SECURITY_ENCLAVE_OVERRIDE=/bridge
fi

# Match sim/monitor transport.
export FASTRTPS_DEFAULT_PROFILES_FILE=/home/f1tenth/udp_only.xml

exec stdbuf -oL python3 -c "
import time, rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from std_msgs.msg import String
rclpy.init()
n = Node('alerts_sniffer')
qos = QoSProfile(reliability=ReliabilityPolicy.RELIABLE,
                 durability=DurabilityPolicy.VOLATILE,
                 history=HistoryPolicy.KEEP_LAST, depth=50)
def cb(msg):
    print(f'[{time.time():.3f}] {msg.data}', flush=True)
n.create_subscription(String, '/monitor_alerts', cb, qos)
print('sniffer up', flush=True)
rclpy.spin(n)
"
