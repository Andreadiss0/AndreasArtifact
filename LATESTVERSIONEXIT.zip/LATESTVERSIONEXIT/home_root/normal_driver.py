#!/usr/bin/env python3
"""Left-wall follower for the f1tenth_gym Levine map -- laps the central
rectangle counter-clockwise without entering the dead-end branches."""

import math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped


class NormalDriver(Node):
    def __init__(self):
        super().__init__('normal_driver')
        self.drive_pub = self.create_publisher(
            AckermannDriveStamped, '/drive', 10)
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.on_scan, 10)
        self.timer = self.create_timer(0.05, self.publish_drive)

        # Latest decision.
        self.target_steering = 0.0
        self.have_scan = False

        # Tunables.
        self.constant_speed   = 1.0     # always moving
        self.target_distance  = 1.0     # meters from the LEFT wall (further out
                                        # so small bumps don't reach us)
        self.lookahead        = 1.0     # meters ahead -- predict where we'll be
        self.theta_deg        = 45.0    # angle between the two reference beams
        self.kp               = 1.0     # proportional gain on the wall-distance error
        self.max_steering     = 0.40    # hard cap on output
        self.smooth_factor    = 0.5     # low-pass on steering
        # Front-emergency: only fires on imminent collisions; steers AWAY from
        # whichever side is closer, not blindly right.
        self.front_emerg_dist = 0.6     # meters (was 1.4 -- too aggressive)
        self.front_emerg_fov  = 30.0    # degrees half-cone
        self.emerg_steering_mag = 0.40  # magnitude of emergency steer

        self.get_logger().info('normal_driver up (left-wall-follow) -- publishing /drive @ 20 Hz')

    @staticmethod
    def _range_at(msg, target_angle):
        """Return the LiDAR range at the beam closest to `target_angle` (rad).
        Caps NaN/Inf/zero to a safe large value."""
        idx = int(round((target_angle - msg.angle_min) / msg.angle_increment))
        idx = max(0, min(len(msg.ranges) - 1, idx))
        r = msg.ranges[idx]
        if math.isnan(r) or math.isinf(r) or r <= 0.05:
            return 10.0
        return r

    def on_scan(self, msg):
        if len(msg.ranges) < 100:
            return

        # Front-emergency check first: if anything in the front cone is too
        # close, override the wall-follower and steer away from whichever
        # side (left vs right) is closer.
        emerg_fov = math.radians(self.front_emerg_fov)
        n_steps = 11
        front_min = 10.0
        for j in range(n_steps):
            frac = j / (n_steps - 1)
            angle = -emerg_fov + frac * 2 * emerg_fov
            d = self._range_at(msg, angle)
            if d < front_min:
                front_min = d
        if front_min < self.front_emerg_dist:
            left_dist  = self._range_at(msg, math.pi / 2.0)
            right_dist = self._range_at(msg, -math.pi / 2.0)
            # If left is closer, steer right (-ve); else steer left (+ve).
            emerg = -self.emerg_steering_mag if left_dist < right_dist else self.emerg_steering_mag
            self.target_steering = (self.smooth_factor * self.target_steering
                                    + (1.0 - self.smooth_factor) * emerg)
            self.have_scan = True
            return

        # Two reference beams on the LEFT side of the car:
        #   b is perpendicular to the car's heading (90 deg left)
        #   a is at theta degrees forward of b (so 90 - theta deg)
        theta = math.radians(self.theta_deg)
        b = self._range_at(msg, math.pi / 2.0)           # straight left
        a = self._range_at(msg, math.pi / 2.0 - theta)   # front-left

        # alpha = angle between the car's heading and the left wall.
        # Derived from the standard F1TENTH wall-follow geometry.
        denom = a * math.sin(theta)
        if abs(denom) < 1e-3:
            return
        alpha = math.atan2(a * math.cos(theta) - b, denom)
        # Perpendicular distance from the car to the left wall right now.
        perp_dist = b * math.cos(alpha)
        # Project that distance L meters ahead.
        future_dist = perp_dist + self.lookahead * math.sin(alpha)

        # Error: positive if we're too far from the wall, want to steer left.
        # (kp * error -> +ve steering = left, -ve = right).
        error = self.target_distance - future_dist
        raw_steer = -self.kp * error
        raw_steer = max(-self.max_steering, min(self.max_steering, raw_steer))

        # Low-pass smoothing.
        self.target_steering = (self.smooth_factor * self.target_steering
                                + (1.0 - self.smooth_factor) * raw_steer)
        self.have_scan = True

    def publish_drive(self):
        msg = AckermannDriveStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'normal_driver'
        msg.drive.speed = float(self.constant_speed)
        msg.drive.steering_angle = float(self.target_steering)
        self.drive_pub.publish(msg)


def main():
    rclpy.init()
    node = NormalDriver()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        stop = AckermannDriveStamped()
        stop.drive.speed = 0.0
        stop.drive.steering_angle = 0.0
        try:
            node.drive_pub.publish(stop)
        except Exception:
            pass
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
