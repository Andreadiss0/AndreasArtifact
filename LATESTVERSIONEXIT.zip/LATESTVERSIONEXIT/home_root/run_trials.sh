#!/bin/bash
# Orchestrator: runs monitor + sniffer + defender in background and attacker N times.
# Usage:
#   ~/run_trials.sh          # default 10 trials
#   ~/run_trials.sh 5        # 5 trials

set -u
TRIALS=${1:-10}
ROOT=/home/f1tenth/finalVersion/trials
mkdir -p "$ROOT"

cleanup_procs() {
  for pid in $(pgrep -f "system_monitor_v2/lib/system_monitor_v2/system_monitor_node"); do kill "$pid" 2>/dev/null; done
  for pid in $(pgrep -f "defender_agent.py"); do kill "$pid" 2>/dev/null; done
  for pid in $(pgrep -f "Node..alerts_sniffer"); do kill "$pid" 2>/dev/null; done
  for pid in $(pgrep -f "ros2 run system_monitor_v2"); do kill "$pid" 2>/dev/null; done
  for p in /proc/[0-9]*; do
    c=$(cat "$p/cmdline" 2>/dev/null | tr '\0' ' ')
    case "$c" in
      attacker_*) kill "$(basename $p)" 2>/dev/null ;;
    esac
  done
  for pid in $(pgrep -f "attacker_pub|attacker_sub|attacker_exfil|cross_topic_correlation|attacker_ros_participant|attacker_scan_reader|attacker_odom_reader|attacker_drive_writer|attacker_drive_flooder|attacker_scan_writer|attacker_scan_corrupter|attacker_qos_degrader|reliability_flip_scan_attack|mitm_scan_attack|stale_publish_scan_attack|attacker_lifecycle|attacker_bridge_param|attacker_map_param"); do kill -9 "$pid" 2>/dev/null; done
  for pid in $(pgrep -f "test_scan_qos|test_scan_corrupter|test_scan_reader|test_drive_flooder|test_drive_unsafe|test_lifecycle_attacker|test_bridge_attacker|test_intruder|verify_inducers"); do kill -9 "$pid" 2>/dev/null; done
  sudo -n tc qdisc del dev lo root 2>/dev/null
  sudo -n tc qdisc del dev eth0 root 2>/dev/null
  sudo -n tc qdisc del dev wlan0 root 2>/dev/null
  sleep 0.3
}

reset_state() {
  rm -f /home/f1tenth/finalVersion/state.json
  rm -f /tmp/turn_complete.flag
  rm -f /tmp/defender_last_turn.json
  rm -f /tmp/attacker_step_done.flag
  rm -f /tmp/stolen_ros_creds /tmp/attacker_netadmin.log /tmp/bridge_recon.log
  rm -rf /tmp/stolen_ros_keystore 2>/dev/null
  rm -f /tmp/runtime_combined.log /tmp/runtime_combined.start_ts
  ros2 daemon stop 2>/dev/null || true
  sleep 0.3
}

run_trial() {
  local n=$1
  local d=$ROOT/trial_$n
  rm -rf "$d"
  mkdir -p "$d"

  echo ""
  echo "================================================================="
  echo "  TRIAL $n / $TRIALS"
  echo "================================================================="

  cleanup_procs
  reset_state

  echo "[trial $n] starting monitor (6 s warm-up for DDS discovery)..."
  ~/run_monitor.sh > "$d/monitor.log" 2>&1 &
  echo $! > "$d/monitor.pid"
  sleep 6

  ~/reset_car.sh >/dev/null 2>&1
  sleep 0.5

  pkill -USR1 -f "system_monitor_v2/lib/system_monitor_v2/system_monitor_node" 2>/dev/null || true
  sleep 0.2

  echo "[trial $n] starting alerts sniffer..."
  ~/run_alerts.sh > "$d/alerts.log" 2>&1 &
  echo $! > "$d/sniffer.pid"
  sleep 0.3

  echo "[trial $n] starting defender..."
  ~/run_defender.sh > "$d/defender.log" 2>&1 &
  echo $! > "$d/defender.pid"
  sleep 0.3

  echo "[trial $n] running attacker..."
  ~/run_attacker.sh > "$d/attacker.log" 2>&1
  ATT_RC=$?

  sleep 0.3

  cp /tmp/runtime_combined.log "$d/combined.log" 2>/dev/null || true

  if grep -q "Attacker reached systemCompromised" "$d/attacker.log"; then
    verdict="ATTACKER_WIN"
  elif grep -q "Attacker gave up" "$d/attacker.log"; then
    verdict="DEFENDER_WIN_GIVE_UP"
  elif grep -q "Attacker cost budget exhausted" "$d/attacker.log"; then
    verdict="DEFENDER_WIN_COST_EXHAUSTED"
  elif grep -q "MAX_STEPS=.* reached without compromise" "$d/attacker.log"; then
    verdict="DEFENDER_WIN_TIMEOUT"
  else
    verdict="UNKNOWN"
  fi

  steps=$(grep -c '========== ATTACK STEP' "$d/attacker.log")
  alerts=$(grep -cE '^\[1[0-9]+\.' "$d/alerts.log")
  defenses=$(grep -c 'strategy says:' "$d/defender.log")
  alert_list=$(grep -oE 'REQ_[a-z_]+' "$d/alerts.log" | sort -u | tr '\n' ',' | sed 's/,$//')
  defense_list=$(grep -oE 'def_[a-z_]+' "$d/defender.log" | sort -u | tr '\n' ',' | sed 's/,$//')

  echo "[trial $n] DONE"
  echo "         verdict   : $verdict"
  echo "         steps     : $steps"
  echo "         alerts    : $alerts  ($alert_list)"
  echo "         defenses  : $defenses ($defense_list)"
  echo "         logs at   : $d/"

  echo "$n,$verdict,$steps,$alerts,$defenses,\"$alert_list\",\"$defense_list\"" >> "$ROOT/summary.csv"

  # SAFETY: send a final zero-velocity command BEFORE killing the trial
  # stack. gym_bridge holds the last /drive command forever; if we kill
  # everything mid-cruise, the car keeps drifting at its last velocity
  # until it hits a wall ("phantom-velocity crash" between trials).
  python3 - <<'PYEOF' 2>/dev/null
import os, time, rclpy
os.environ.setdefault("ROS_DOMAIN_ID","0")
os.environ.update(dict(ROS_SECURITY_ENABLE="true", ROS_SECURITY_STRATEGY="Enforce",
    ROS_SECURITY_KEYSTORE="/home/f1tenth/sros2_keystore_f1tenth",
    ROS_SECURITY_ENCLAVE_OVERRIDE="/bridge",
    FASTRTPS_DEFAULT_PROFILES_FILE="/home/f1tenth/udp_only.xml"))
from rclpy.node import Node
from ackermann_msgs.msg import AckermannDriveStamped
rclpy.init()
n = Node('between_trial_stop')
pub = n.create_publisher(AckermannDriveStamped, '/drive', 10)
deadline = time.time() + 1.0
while time.time() < deadline and pub.get_subscription_count() == 0:
    time.sleep(0.02)
m = AckermannDriveStamped()
end = time.time() + 0.3
while time.time() < end:
    pub.publish(m)
    time.sleep(0.025)   # 40 Hz, below monitor's REQ_drive_DoS guard
n.destroy_node(); rclpy.shutdown()
PYEOF

  # HARD kill by process pattern, not by .pid (those hold the bash
  # wrapper's PID; the python defender is a child and survives SIGTERM
  # on its parent). With SIGKILL the defender's brake thread dies too,
  # so the next trial starts with no leftover zero-velocity publisher.
  pkill -9 -f "system_monitor_v2/lib/system_monitor_v2/system_monitor_node" 2>/dev/null
  pkill -9 -f "defender_agent.py" 2>/dev/null
  pkill -9 -f "Node..alerts_sniffer" 2>/dev/null
  pkill -9 -f "ros2 run system_monitor_v2" 2>/dev/null
  sleep 0.3
}

rm -rf "$ROOT"/trial_*
echo "trial,verdict,steps,alerts,defenses,alert_list,defense_list" > "$ROOT/summary.csv"

if ! pgrep -f "gym_bridge" > /dev/null; then
  echo "ERROR: simulator does not appear to be running."
  echo "Start it in T1 first:  ~/run_sim.sh"
  exit 1
fi

for i in $(seq 1 "$TRIALS"); do
  run_trial "$i"
done

echo ""
echo "================================================================="
echo "  ALL $TRIALS TRIALS COMPLETE"
echo "================================================================="
echo ""
column -t -s, "$ROOT/summary.csv" | head -n $((TRIALS + 1))
echo ""
echo "Win rates:"
awin=$(grep -c ATTACKER_WIN "$ROOT/summary.csv")
dwin_giveup=$(grep -c DEFENDER_WIN_GIVE_UP "$ROOT/summary.csv")
dwin_timeout=$(grep -c DEFENDER_WIN_TIMEOUT "$ROOT/summary.csv")
echo "  attacker wins (systemCompromised) : $awin / $TRIALS"
echo "  defender wins (give-up)           : $dwin_giveup / $TRIALS"
echo "  defender wins (timeout)           : $dwin_timeout / $TRIALS"
echo ""
echo "Per-trial logs : $ROOT/trial_N/{attacker,monitor,defender,alerts}.log"
echo "Summary CSV    : $ROOT/summary.csv"
