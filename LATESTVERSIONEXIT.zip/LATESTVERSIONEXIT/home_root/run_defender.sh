#!/bin/bash
# Strategy-driven defender (subscribes to /monitor_alerts).
source /opt/ros/foxy/setup.bash
source ~/sim_ws/install/setup.bash
source ~/monitor_ws_v2/install/setup.bash
export ROS_DOMAIN_ID=0
export ROS_LOCALHOST_ONLY=0

# SROS2 creds for /bridge enclave.
if [ "${USE_SROS2:-1}" = "1" ]; then
    export ROS_SECURITY_ENABLE=true
    export ROS_SECURITY_STRATEGY=Enforce
    export ROS_SECURITY_KEYSTORE=/home/f1tenth/sros2_keystore_f1tenth
    export ROS_SECURITY_ENCLAVE_OVERRIDE=/bridge
fi

# Match sim/monitor transport.
export FASTRTPS_DEFAULT_PROFILES_FILE=/home/f1tenth/udp_only.xml

# synth (default) | random | none — set by run_experiment.sh
export DEFENDER_POLICY=${DEFENDER_POLICY:-synth}

STRAT_FILE=${DEFENDER_STRAT_FILE:-/home/f1tenth/finalVersion/Strat.txt}
python3 ~/finalVersion/defender_agent.py "$STRAT_FILE"
