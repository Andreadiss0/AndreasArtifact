#!/bin/bash
# 3-treatment defender comparison (none / random / synth).
# Goal: empirical compromise rate per treatment vs PRISM Pmax = 0.2.
#
# Usage:
#   ~/run_experiment.sh                  # default 10 trials per treatment
#   N=20 ~/run_experiment.sh             # 20 trials per treatment
#   POLICIES="none random synth" N=10 ~/run_experiment.sh   # explicit
#
# Output: /home/f1tenth/finalVersion/experiment/
#   policy_<NAME>/trial_<N>/{attacker,monitor,defender,alerts,combined}.log
#   policy_<NAME>/summary.csv
#   experiment_summary.csv  (one row per trial, all treatments)
#   experiment_results.txt  (rolled-up rates table)

set -u
N=${N:-10}
POLICIES=${POLICIES:-"none random synth"}

ROOT=${EXPERIMENT_ROOT:-/home/f1tenth/finalVersion/experiment}
mkdir -p "$ROOT"
rm -f "$ROOT"/experiment_summary.csv "$ROOT"/experiment_results.txt
echo "policy,trial,verdict,steps,alerts,defenses,alert_list,defense_list" \
  > "$ROOT"/experiment_summary.csv

if ! pgrep -f "gym_bridge" > /dev/null; then
  echo "ERROR: simulator does not appear to be running. Start ~/run_sim.sh first."
  exit 1
fi
if ! pgrep -f "normal_driver" > /dev/null; then
  echo "WARNING: normal_op/normal_driver is NOT running. The monitor will see"
  echo "         no baseline /drive rate and may behave oddly. Recommend"
  echo "         ~/run_normal_op.sh in another terminal before continuing."
  echo "         Continuing in 5 s..."
  sleep 5
fi

cleanup_procs() {
  for pid in $(pgrep -f "system_monitor_v2/lib/system_monitor_v2/system_monitor_node"); do kill "$pid" 2>/dev/null; done
  for pid in $(pgrep -f "defender_agent.py"); do kill "$pid" 2>/dev/null; done
  for pid in $(pgrep -f "Node..alerts_sniffer"); do kill "$pid" 2>/dev/null; done
  for pid in $(pgrep -f "ros2 run system_monitor_v2"); do kill "$pid" 2>/dev/null; done
  for p in /proc/[0-9]*; do
    c=$(cat "$p/cmdline" 2>/dev/null | tr '\0' ' ')
    case "$c" in
      attacker_*) kill "$(basename $p)" 2>/dev/null ;;
    esac
  done
  for pid in $(pgrep -f "attacker_pub|attacker_sub|attacker_exfil|cross_topic_correlation|attacker_ros_participant|attacker_scan_reader|attacker_odom_reader|attacker_drive_writer|attacker_drive_flooder|attacker_scan_writer|attacker_scan_corrupter|attacker_qos_degrader|reliability_flip_scan_attack|mitm_scan_attack|stale_publish_scan_attack|attacker_lifecycle|attacker_bridge_param|attacker_map_param"); do kill -9 "$pid" 2>/dev/null; done
  for pid in $(pgrep -f "test_scan_qos|test_scan_corrupter|test_scan_reader|test_drive_flooder|test_drive_unsafe|test_lifecycle_attacker|test_bridge_attacker|test_intruder|verify_inducers"); do kill -9 "$pid" 2>/dev/null; done
  sudo -n tc qdisc del dev lo root 2>/dev/null
  sudo -n tc qdisc del dev eth0 root 2>/dev/null
  sudo -n tc qdisc del dev wlan0 root 2>/dev/null
  sleep 0.3
}

reset_state() {
  rm -f /home/f1tenth/finalVersion/state.json
  rm -f /tmp/turn_complete.flag /tmp/defender_last_turn.json /tmp/attacker_step_done.flag
  rm -f /tmp/stolen_ros_creds /tmp/attacker_netadmin.log /tmp/bridge_recon.log
  rm -rf /tmp/stolen_ros_keystore 2>/dev/null
  rm -f /tmp/runtime_combined.log /tmp/runtime_combined.start_ts
  ros2 daemon stop 2>/dev/null || true
  sleep 0.3
}

between_trials_brake() {
  python3 - <<'PYEOF' 2>/dev/null
import os, time, rclpy
os.environ.setdefault("ROS_DOMAIN_ID","0")
os.environ.update(dict(ROS_SECURITY_ENABLE="true", ROS_SECURITY_STRATEGY="Enforce",
    ROS_SECURITY_KEYSTORE="/home/f1tenth/sros2_keystore_f1tenth",
    ROS_SECURITY_ENCLAVE_OVERRIDE="/bridge",
    FASTRTPS_DEFAULT_PROFILES_FILE="/home/f1tenth/udp_only.xml"))
from rclpy.node import Node
from ackermann_msgs.msg import AckermannDriveStamped
rclpy.init()
n = Node('between_trial_stop')
pub = n.create_publisher(AckermannDriveStamped, '/drive', 10)
deadline = time.time() + 1.0
while time.time() < deadline and pub.get_subscription_count() == 0:
    time.sleep(0.02)
m = AckermannDriveStamped()
end = time.time() + 0.3
while time.time() < end:
    pub.publish(m); time.sleep(0.025)
n.destroy_node(); rclpy.shutdown()
PYEOF
}

run_trial() {
  local policy=$1 n=$2
  local d=$POLICY_ROOT/trial_$n
  rm -rf "$d"; mkdir -p "$d"

  echo ""
  echo "===== [$policy] TRIAL $n / $N ====="

  cleanup_procs
  reset_state

  ~/run_monitor.sh > "$d/monitor.log" 2>&1 &
  echo $! > "$d/monitor.pid"
  sleep 6

  ~/reset_car.sh >/dev/null 2>&1
  sleep 0.5
  pkill -USR1 -f "system_monitor_v2/lib/system_monitor_v2/system_monitor_node" 2>/dev/null || true
  sleep 0.2

  ~/run_alerts.sh > "$d/alerts.log" 2>&1 &
  echo $! > "$d/sniffer.pid"
  sleep 0.3

  # Skip defender process for policy=none so no defense events fire.
  if [ "$policy" != "none" ]; then
    DEFENDER_POLICY=$policy ~/run_defender.sh > "$d/defender.log" 2>&1 &
    echo $! > "$d/defender.pid"
    sleep 0.3
  else
    echo "(no defender process — policy=none)" > "$d/defender.log"
  fi

  # per-trial watchdog: a hung attacker subprocess can't stall the loop.
  # 180s is generous (cost-budget=20, typical trial <60s).
  timeout --foreground --kill-after=15s 180s ~/run_attacker.sh > "$d/attacker.log" 2>&1
  ATT_RC=$?
  if [ "$ATT_RC" -eq 124 ] || [ "$ATT_RC" -eq 137 ]; then
    echo "[WATCHDOG] trial $n hit 180s timeout (rc=$ATT_RC); marking TIMEOUT_HUNG" \
      >> "$d/attacker.log"
  fi
  sleep 0.3

  cp /tmp/runtime_combined.log "$d/combined.log" 2>/dev/null || true

  local verdict
  if grep -q "Attacker reached systemCompromised" "$d/attacker.log"; then
    verdict="ATTACKER_WIN"
  elif grep -q "Attacker gave up" "$d/attacker.log"; then
    verdict="DEFENDER_WIN_GIVE_UP"
  elif grep -q "Attacker cost budget exhausted" "$d/attacker.log"; then
    verdict="DEFENDER_WIN_COST_EXHAUSTED"
  elif grep -q "MAX_STEPS=.* reached without compromise" "$d/attacker.log"; then
    verdict="DEFENDER_WIN_TIMEOUT"
  else
    verdict="UNKNOWN"
  fi

  local steps alerts defenses alert_list defense_list
  # grep -c always prints a number; exit code is ignored. The || echo 0
  # pattern was adding a SECOND "0" on no-match and breaking the CSV row.
  steps=$(grep -c '========== ATTACK STEP' "$d/attacker.log" 2>/dev/null)
  alerts=$(grep -cE '^\[1[0-9]+\.' "$d/alerts.log" 2>/dev/null)
  defenses=$(grep -c 'strategy says:' "$d/defender.log" 2>/dev/null)
  steps=${steps:-0}; alerts=${alerts:-0}; defenses=${defenses:-0}
  alert_list=$(grep -oE 'REQ_[a-z_]+' "$d/alerts.log" 2>/dev/null | sort -u | tr '\n' '|' | sed 's/|$//')
  defense_list=$(grep -oE 'def_[a-z_]+' "$d/defender.log" 2>/dev/null | sort -u | tr '\n' '|' | sed 's/|$//')

  echo "  verdict=$verdict steps=$steps alerts=$alerts defenses=$defenses"
  echo "$n,$verdict,$steps,$alerts,$defenses,$alert_list,$defense_list" \
    >> "$POLICY_ROOT"/summary.csv
  echo "$policy,$n,$verdict,$steps,$alerts,$defenses,$alert_list,$defense_list" \
    >> "$ROOT"/experiment_summary.csv

  between_trials_brake

  pkill -9 -f "system_monitor_v2/lib/system_monitor_v2/system_monitor_node" 2>/dev/null
  pkill -9 -f "defender_agent.py" 2>/dev/null
  pkill -9 -f "Node..alerts_sniffer" 2>/dev/null
  pkill -9 -f "ros2 run system_monitor_v2" 2>/dev/null
  sleep 0.3
}

for policy in $POLICIES; do
  POLICY_ROOT=$ROOT/policy_$policy
  # SKIP_DONE=1 keeps any existing trial_* dirs and only fills the gap up
  # to N. Useful when resuming after a crash.
  if [ "${SKIP_DONE:-0}" = "1" ] && [ -d "$POLICY_ROOT" ]; then
    echo "(SKIP_DONE=1: keeping existing $POLICY_ROOT)"
  else
    rm -rf "$POLICY_ROOT"
  fi
  mkdir -p "$POLICY_ROOT"
  [ -f "$POLICY_ROOT/summary.csv" ] || \
    echo "trial,verdict,steps,alerts,defenses,alert_list,defense_list" \
      > "$POLICY_ROOT"/summary.csv

  echo ""
  echo "================================================================="
  echo "  POLICY = $policy   (N=$N)"
  echo "================================================================="
  for i in $(seq 1 "$N"); do
    run_trial "$policy" "$i"
  done
done

echo ""
echo "================================================================="
echo "  ALL TREATMENTS DONE — building results table"
echo "================================================================="

python3 /home/f1tenth/finalVersion/experiment_aggregate.py "$ROOT" \
  | tee "$ROOT"/experiment_results.txt

echo ""
echo "Per-trial logs : $ROOT/policy_<NAME>/trial_N/"
echo "Combined CSV   : $ROOT/experiment_summary.csv"
echo "Results table  : $ROOT/experiment_results.txt"
