#!/bin/bash
# Normal-operation drive loop (no attacker, no defender). Run after the sim is up.
# Usage:
#   ~/run_normal_op.sh                 # run until ctrl-C
#   DURATION=30 ~/run_normal_op.sh     # stop after 30 seconds

source /opt/ros/foxy/setup.bash
source ~/sim_ws/install/setup.bash
export ROS_DOMAIN_ID=0
export ROS_LOCALHOST_ONLY=0

if [ "${USE_SROS2:-1}" = "1" ]; then
    export ROS_SECURITY_ENABLE=true
    export ROS_SECURITY_STRATEGY=Enforce
    export ROS_SECURITY_KEYSTORE=/home/f1tenth/sros2_keystore_f1tenth
    export ROS_SECURITY_ENCLAVE_OVERRIDE=/bridge
fi

# Match sim/monitor transport.
export FASTRTPS_DEFAULT_PROFILES_FILE=/home/f1tenth/udp_only.xml

# Pre-flight: sim must be up.
if ! pgrep -f gym_bridge > /dev/null; then
    echo "ERROR: simulator not running. Start it in T1 first:  ~/run_sim.sh"
    exit 1
fi

DURATION=${DURATION:-0}
if [ "$DURATION" -gt 0 ]; then
    echo "[normal_op] driving for ${DURATION} s..."
    timeout "${DURATION}s" python3 /home/f1tenth/normal_driver.py 2>&1 | tee /tmp/normal_op.log
else
    echo "[normal_op] driving until ctrl-C..."
    python3 /home/f1tenth/normal_driver.py 2>&1 | tee /tmp/normal_op.log
fi
