#!/bin/bash
# Cleanup leftovers and launch the gym_bridge sim.
sudo tc qdisc del dev lo root 2>/dev/null
pkill -9 -f gym_bridge
pkill -9 -f system_monitor_node
pkill -9 -f rviz2
pkill -9 -f map_server
pkill -9 -f lifecycle_manager
pkill -9 -f robot_state_publisher
pkill -9 -f "topic pub"
pkill -9 -f "topic echo"
pkill -9 -f _ros2_daemon
# Also kill anything from previous trial sessions in this VM.
pkill -9 -f defender_agent.py
pkill -9 -f attacker_agent_test.py
pkill -9 -f normal_driver
pkill -9 -f alerts_sniffer
pkill -9 -f "ros2 run system_monitor_v2"
ros2 daemon stop 2>/dev/null
rm -rf /dev/shm/*
sleep 3
echo "cleanup done"

source /opt/ros/foxy/setup.bash
source ~/sim_ws/install/setup.bash
export ROS_DOMAIN_ID=0
export ROS_LOCALHOST_ONLY=0

# SROS2 enforcement (toggle off with USE_SROS2=0).
if [ "${USE_SROS2:-1}" = "1" ]; then
    export ROS_SECURITY_ENABLE=true
    export ROS_SECURITY_STRATEGY=Enforce
    export ROS_SECURITY_KEYSTORE=/home/f1tenth/sros2_keystore_f1tenth
    export ROS_SECURITY_ENCLAVE_OVERRIDE=/bridge
    echo "[run_sim] SROS2 enforced (keystore=$ROS_SECURITY_KEYSTORE, enclave=/bridge)"
else
    echo "[run_sim] SROS2 DISABLED (USE_SROS2=0)"
fi

# Force FastRTPS to UDPv4-only so tc netem rules on lo apply.
export FASTRTPS_DEFAULT_PROFILES_FILE=/home/f1tenth/udp_only.xml

ros2 launch f1tenth_gym_ros gym_bridge_launch.py
