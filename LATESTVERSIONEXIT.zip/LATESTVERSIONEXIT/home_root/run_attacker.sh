#!/bin/bash
# Graph-driven attacker agent (resets state.json each run).
source /opt/ros/foxy/setup.bash
source ~/sim_ws/install/setup.bash
source ~/monitor_ws_v2/install/setup.bash
export ROS_DOMAIN_ID=0
export ROS_LOCALHOST_ONLY=0

# Attacker starts UNAUTHENTICATED; creds activated dynamically on credentialAccess success.
unset ROS_SECURITY_ENABLE
unset ROS_SECURITY_STRATEGY
unset ROS_SECURITY_KEYSTORE
unset ROS_SECURITY_ENCLAVE_OVERRIDE

# Pacing between attacker actions. Effect attacks (topicDrop/Delay/etc)
# need ~3-4 s for monitor detection + sniffer + defender + revoke. The
# extra_defense_wait poll exits early when the defender posts a summary,
# so deterministic steps with no detectable signal stay fast.
export WAIT_BETWEEN_STEPS=${WAIT_BETWEEN_STEPS:-0.5}
export TURN_TIMEOUT_SEC=${TURN_TIMEOUT_SEC:-1.0}
export EXTRA_DEFENSE_WAIT_SEC=${EXTRA_DEFENSE_WAIT_SEC:-5.0}
# Cap by effort cost (DREAD R+E+Di), not step count.
# 30 is just above PRISM's expected equilibrium cost (28.9) so an
# unopposed attacker can finish the chain without hitting the budget wall.
export ATTACK_BUDGET_TOTAL=${ATTACK_BUDGET_TOTAL:-30}
export MAX_STEPS=${MAX_STEPS:-1000}

# Interface for netem-based topicDrop/topicDelay attacks.
export ATTACK_NETEM_IFACE=${ATTACK_NETEM_IFACE:-lo}
export ATTACK_TC_PREFIX=${ATTACK_TC_PREFIX:-sudo -n tc}

rm -f ~/finalVersion/state.json /tmp/defender_last_turn.json
rm -f /tmp/turn_complete.flag /tmp/attacker_step_done.flag
rm -rf /tmp/stolen_ros_keystore 2>/dev/null

# Match sim/monitor transport.
export FASTRTPS_DEFAULT_PROFILES_FILE=/home/f1tenth/udp_only.xml

cd ~/finalVersion && python3 attacker_agent_test.py AttackGraph.dot
