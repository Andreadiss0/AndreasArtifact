#!/bin/bash
# Teleport the car back to spawn (0, 0, 0) via the bridge's /initialpose
# subscriber. Uses a Python rclpy publisher that waits for the subscriber
# to actually match before sending -- `ros2 topic pub --once` from the
# CLI races DDS discovery and the message often lands nowhere.
source /opt/ros/foxy/setup.bash
source ~/sim_ws/install/setup.bash > /dev/null 2>&1
export ROS_DOMAIN_ID=0
export ROS_LOCALHOST_ONLY=0
export ROS_SECURITY_ENABLE=true
export ROS_SECURITY_STRATEGY=Enforce
export ROS_SECURITY_KEYSTORE=/home/f1tenth/sros2_keystore_f1tenth
export ROS_SECURITY_ENCLAVE_OVERRIDE=/bridge
export FASTRTPS_DEFAULT_PROFILES_FILE=/home/f1tenth/udp_only.xml

python3 - <<'PYEOF'
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped
import time
rclpy.init()
n = Node("reset_car_pose_publisher")
pub = n.create_publisher(PoseWithCovarianceStamped, "/initialpose", 10)
deadline = time.time() + 3.0
while time.time() < deadline and pub.get_subscription_count() == 0:
    time.sleep(0.1)
if pub.get_subscription_count() == 0:
    print("[reset_car] WARN: /initialpose has no subscriber after 3 s")
msg = PoseWithCovarianceStamped()
msg.header.frame_id = "map"
# Verified-open corridor positions (levine.png pixel >=250):
#   (-1, 0)  -> bottom horizontal corridor (value=255)
#   (-1, 8)  -> top horizontal corridor (value=255)
# Prior target (-1, 10) was actually a wall pixel (value=216).
msg.pose.pose.position.x = -1.0
msg.pose.pose.position.y = 0.0
msg.pose.pose.orientation.w = 1.0
for _ in range(5):
    pub.publish(msg)
    time.sleep(0.05)
n.destroy_node()
rclpy.shutdown()
PYEOF

echo "[reset_car] published /initialpose (0,0,0) -- car teleported to spawn"
