# F1TENTH Self-Protection Runtime: Code Guide

This README is for a teammate who wants to understand how the system works, where the code lives, and how to run it on a new machine.

## Project Purpose

This repo runs a full attacker-monitor-defender loop on a live ROS 2 f1tenth simulator. The attacker walks a MulVAL-generated attack graph and executes real Linux/ROS 2 actions. A Copilot-generated runtime monitor watches topics and processes and fires alerts. A PRISM-games strategy-driven defender reacts to those alerts.

Core idea:
- `AttackGraph.dot` defines what attacks are possible and in what order.
- `attacker_agent_test.py` executes real subprocesses for each enabled attack.
- `system_monitor_node` (C++ + Monitor.c) detects effects and publishes alerts on `/monitor_alerts`.
- `defender_agent.py` reads a precomputed PRISM strategy file (`Strat.txt`) and runs defenses.
- The trial ends when the attacker reaches `systemCompromised(f1tenth)` or runs out of budget.

## Directory Layout After Install

```
~/
  run_sim.sh              launches f1tenth_gym_ros + rviz
  run_monitor.sh          starts system_monitor_node
  run_attacker.sh         runs one attacker trial
  run_defender.sh         starts the PRISM-strategy defender
  run_trials.sh           orchestrator: N automated trials end-to-end
  run_experiment.sh       3-treatment comparison (none / random / synth)
  run_alerts.sh           rclpy sniffer for /monitor_alerts (viewer)
  run_normal_op.sh        baseline drive loop (no attacker)
  reset_car.sh            teleports car back to spawn via /initialpose
  normal_driver.py        the baseline driver node
  udp_only.xml            FastRTPS config: UDPv4-only (required for tc netem)

~/finalVersion/
  attacker_agent_test.py  main attacker engine (28 actions, PRISM dice)
  defender_agent.py       defender node (subscribes /monitor_alerts)
  Strat.txt               PRISM-games strategy file (11,682 state entries)
  AttackGraph.dot         MulVAL attack graph, L1 canonical (182 nodes)
  RosRULEScopy.txt        Prolog rules used to generate the attack graph
  vulns.txt               facts (hosts, topics, DDS config) fed to MulVAL
  state.json              attacker runtime state (recreated each trial)
  experiment_aggregate.py post-run aggregator for experiment results
  L0AttackGraph.dot       scalability level 0 graph (~120 nodes)
  L0STRAT.txt             PRISM strategy for L0
  L2AttackGraph.dot       scalability level 2 graph (~305 nodes)
  L2STRAT.txt             PRISM strategy for L2
  L3AttackGraph.dot       scalability level 3 graph (~419 nodes)
  runners/                experiment runner scripts (see runners/README.md)

~/monitor_ws_v2/src/system_monitor_v2/
  CMakeLists.txt          build config
  package.xml             ROS 2 package manifest
  src/
    system_monitor_node.cpp   C++ ROS 2 wrapper (35 extern vars, 1 Hz tick)
    Monitor.c                 Copilot-generated PTLTL monitor (13 FRET reqs)
    Monitor.h / monitor.h     generated headers
    monitor_types.h           type definitions

~/sim_ws/src/f1tenth_gym_ros/   standard f1tenth simulator (clone from GitHub)
```

## Prerequisites

Ubuntu 20.04 + ROS 2 Foxy.

```bash
# ROS 2 packages
sudo apt install ros-foxy-ackermann-msgs ros-foxy-lifecycle-msgs \
                 ros-foxy-rclpy python3-colcon-common-extensions

# tc for network-shaping attacks
sudo apt install iproute2
```

The attacker calls `sudo tc qdisc` for `topicDrop` and `topicDelay` attacks.
Add this to `/etc/sudoers` via `visudo` (replace `youruser`):

```
youruser ALL=(ALL) NOPASSWD: /sbin/tc
```

## Install

```bash
# 1. Copy run scripts and support files to home
cp -r LATESTVERSIONEXIT/home_root/. ~/

# 2. Copy the core logic directory
cp -r LATESTVERSIONEXIT/finalVersion ~/finalVersion

# 3. Copy the monitor workspace source
cp -r LATESTVERSIONEXIT/monitor_ws_v2 ~/monitor_ws_v2

# 4. Clone and build the simulator
git clone https://github.com/f1tenth/f1tenth_gym_ros ~/sim_ws/src/f1tenth_gym_ros
cd ~/sim_ws && source /opt/ros/foxy/setup.bash && colcon build

# 5. Build the monitor
cd ~/monitor_ws_v2 && source /opt/ros/foxy/setup.bash && colcon build

# 6. Make scripts executable
chmod +x ~/run_*.sh ~/reset_car.sh ~/finalVersion/runners/*.sh
```

## SROS2 Keystore

All components run under the `/bridge` SROS2 enclave. Either copy the original
keystore from this machine (`~/sros2_keystore_f1tenth/`) or regenerate it:

```bash
export ROS_SECURITY_KEYSTORE=~/sros2_keystore_f1tenth
ros2 security create_keystore $ROS_SECURITY_KEYSTORE
ros2 security create_enclave $ROS_SECURITY_KEYSTORE /bridge
```

To skip SROS2 entirely: set `USE_SROS2=0` before running any script.

## Run Commands

### Quickstart: automated trials (two terminals)

Simulator terminal:

```bash
~/run_sim.sh
# wait for rviz to open and the car to appear (~15 s)
```

Trials terminal:

```bash
~/run_trials.sh 10       # 10 trials, default policy=synth
~/run_trials.sh 5        # 5 trials
```

Each trial runs ~60-80 s. Logs per trial go to `~/finalVersion/trials/trial_N/`.
Summary CSV at `~/finalVersion/trials/summary.csv`.

### 3-treatment experiment (none / random / synth)

```bash
# Simulator still running in T1
N=100 ~/run_experiment.sh                          # all three treatments
POLICIES="synth" N=20 ~/run_experiment.sh          # synth only
POLICIES="none random" N=50 ~/run_experiment.sh    # two treatments
```

Results go to `~/finalVersion/experiment/`. Aggregated table printed at end.

### Manual: 5 separate terminals

```bash
# T1 — simulator
~/run_sim.sh

# T2 — monitor
~/run_monitor.sh

# T3 — alerts viewer (optional)
~/run_alerts.sh

# T4 — defender
~/run_defender.sh

# T5 — one attacker trial
~/run_attacker.sh
```

To reset between manual trials:

```bash
rm -f ~/finalVersion/state.json /tmp/defender_last_turn.json \
      /tmp/turn_complete.flag /tmp/attacker_step_done.flag
~/run_attacker.sh
```

## How `attacker_agent_test.py` Works

### 1) Parse graph

Reads `AttackGraph.dot`, builds predicate nodes, rule nodes, and dependency
edges. Preserves OR semantics across alternative rules so a predicate can be
reached via any single valid path.

### 2) Load/update runtime state

State file is `~/finalVersion/state.json`:
- `predicates`: achieved attack predicates
- `foundation`: long-lived marker processes (spawned once, persist until defender kills them)
- `meta`: turn count, budget spent

Helpers: `load_state()`, `save_state()`, `mark_pred()`.

### 3) Find enabled executable actions

Computes which predicates have all their preconditions satisfied, then filters
to `EXECUTABLE_ATTACK_ACTIONS`. Picks one per `ATTACKER_POLICY` (default `random`).

### 4) Roll PRISM dice

Before running the subprocess, the attacker rolls three-way dice matching the
PRISM-games transition:
- `success` — subprocess runs at full intensity; predicate marked if subprocess exits ok
- `retry` — subprocess runs at ~50% intensity; predicate NOT marked
- `give_up` — subprocess runs at ~20% intensity; predicate NOT marked; if too many give-ups, trial ends as defender win

### 5) Execute action

Dispatch map `ACTION_IMPL = { "<predicate>": <python function> }`.

Examples:
- `initialAccess(engineering_ws)` → `act_initial_access_engineering_ws()` — copies keystore, spawns sleep marker
- `topicWrite('/drive')` → `act_topic_write_drive()` — continuous rclpy publisher on `/drive` for 4 s
- `topicFlood('/scan')` → `act_topic_flood_scan()` — spawns `ros2 topic pub` at 1000 Hz for 8 s
- `topicDelay('/scan')` → `act_topic_delay_scan()` — `tc qdisc netem delay 500ms` on lo
- `serviceCall('/map_server/change_state')` → `act_service_call_map_server_change_state()` — calls lifecycle service

### 6) Turn coordination

After each action the attacker writes `/tmp/attacker_step_done.flag`.
The defender reacts, then writes `/tmp/turn_complete.flag` and
`/tmp/defender_last_turn.json`. The attacker reads the summary and prints a
unified TURN N block before its next step.

Stop conditions: `systemCompromised(f1tenth)` reached, budget exhausted, or
`MAX_STEPS` hit.

## How `defender_agent.py` Works

Subscribes to `/monitor_alerts` (RELIABLE QoS). On each alert:

1. Sets the matching bit in a 14-element state vector.
2. Infers upstream foundation predicates (e.g. an effect alert implies `initialAccess` was already true).
3. Builds a `(b0..b13, turn)` tuple and looks it up in `Strat.txt`.
4. Runs the matched `def_*` defense subprocess.
5. Waits 2.5 s to see if the attacker predicate disappears from `state.json` (revoke check).

Defense actions are real shell commands: `pkill -9 -f <pattern>`, `ros2 lifecycle set`, `ros2 param set`, etc.

## How `system_monitor_node` Works

C++ ROS 2 node. Runs a 1 Hz tick that:
1. Reads topic stats (publisher counts, message rates) from `/scan`, `/drive`, etc.
2. Walks `/proc` to count named attacker marker processes.
3. Feeds 35 `extern` variables into `Monitor.c` (generated by Copilot from FRET/OGMA).
4. `Monitor.c` evaluates 13 PTLTL properties. Each property that fires triggers a `REQ_*` alert published on `/monitor_alerts`.

The 13 monitored requirements:
- `REQ_drive_DoS`, `REQ_command_unsafe`, `REQ_scan_corrupted`, `REQ_scan_unreliable`,
  `REQ_map_server_down`, `REQ_bridge_misconfigured`, `REQ_data_leaked` — effect-layer alerts
- `REQ_can_initial_access`, `REQ_can_lateral_access`, `REQ_can_credential_access`,
  `REQ_can_join_ros_graph`, `REQ_can_net_admin` — foundation-chain alerts (fired by marker processes)

## Environment Variables

| Variable | Default | What it controls |
|---|---|---|
| `ATTACKER_POLICY` | `random` | `random` only currently; `synth` uses Strat.txt attacker side (not yet wired) |
| `ATTACK_BUDGET_TOTAL` | `30` | Max DREAD cost before attacker gives up |
| `WAIT_BETWEEN_STEPS` | `0.5` | Seconds between attacker actions |
| `EXTRA_DEFENSE_WAIT_SEC` | `5.0` | Extra wait after effect attacks for defender to react |
| `ATTACK_NETEM_IFACE` | `lo` | Network interface for tc netem rules |
| `ATTACK_TC_PREFIX` | `sudo -n tc` | tc prefix (adjust if passwordless sudo not set up) |
| `DEFENDER_POLICY` | `synth` | `synth` / `random` / `none` (set by run_experiment.sh) |
| `USE_SROS2` | `1` | Set `0` to disable SROS2 enforcement |

## Where To Edit For New Attacks

1. Add a Python function `act_<name>()` in `attacker_agent_test.py`.
2. Register it in `ACTION_IMPL`.
3. Add the predicate string to `EXECUTABLE_ATTACK_ACTIONS`.
4. Add a PRISM label mapping in `ATTACK_LABEL_TO_PRED` if needed.
5. Add a DREAD cost in the cost table at the top of the file.
6. Re-run and verify the explain chain in the attacker terminal output.

For a new monitor requirement:
1. Add the PTLTL property to `Monitor.c` (or regenerate via OGMA).
2. Add the extern variable feed in `system_monitor_node.cpp`.
3. Add a handler in `defender_agent.py` that maps the new `REQ_*` alert to a defense.
4. Add the defense entry to `Strat.txt` (or re-run PRISM-games on Mac to regenerate it).

## One-Line Mental Model

`AttackGraph.dot` says what is possible, `attacker_agent_test.py` picks one enabled action and runs it for real, `Monitor.c` detects the effect, `defender_agent.py` looks up the right countermove in `Strat.txt` and kills the attacker subprocess.
