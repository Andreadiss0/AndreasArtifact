#!/usr/bin/env python3
# Subscribes to /monitor_alerts, flips matching observable bits,
# queries PRISM Strat.txt at t=2, runs the recommended defense.
# Usage: python3 defender_agent.py <Strat.txt>
import json
import os
import re
import shlex
import subprocess
import sys
import threading
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy
from std_msgs.msg import String
from ackermann_msgs.msg import AckermannDriveStamped
from rcl_interfaces.srv import SetParameters
from rcl_interfaces.msg import Parameter, ParameterType
from lifecycle_msgs.srv import ChangeState
from lifecycle_msgs.msg import TransitionEvent

ATTACKER_STATE_PATH = "/home/f1tenth/finalVersion/state.json"

# Set by DefenderNode.__init__ so free-standing defense_* functions can publish ROS messages.
g_defender_node = None

ALERT_COOLDOWN_SEC = 0.5

TURN_COMPLETE_PATH = "/tmp/turn_complete.flag"


ALERT_TO_VAR = {
    "REQ_drive_DoS":             "drive_DoS_f1tenth_",
    "REQ_command_unsafe":        "command_unsafe_f1tenth_",
    "REQ_scan_corrupted":        "scan_corrupted_f1tenth_",
    "REQ_scan_unreliable":       "scan_unreliable_f1tenth_",
    "REQ_map_server_down":       "map_server_down_f1tenth_",
    "REQ_bridge_misconfigured":  "bridge_misconfigured_f1tenth_",
    "REQ_data_leaked":           "data_leaked_f1tenth_",
    "REQ_credential_access":     "credentialAccess_robot_host_",
    "REQ_can_join_ros_graph":    "attackerCanJoinRosGraph_robot_host_",
    "REQ_can_net_admin":         "attackerCanNetAdmin_robot_host_",
}


# "immediate" defenses intervene while the attack is live; "post_hoc" wait for step_done.
ALERT_TIMING = {
    "REQ_drive_DoS":             "immediate",
    "REQ_command_unsafe":        "immediate",
    "REQ_scan_corrupted":        "immediate",
    "REQ_scan_unreliable":       "immediate",
    "REQ_map_server_down":       "immediate",
    "REQ_bridge_misconfigured":  "immediate",
    "REQ_data_leaked":           "immediate",
    "REQ_credential_access":     "post_hoc",
    "REQ_can_join_ros_graph":    "post_hoc",
    "REQ_can_net_admin":         "post_hoc",
}

ATTACKER_STEP_DONE_PATH = "/tmp/attacker_step_done.flag"

COMBINED_LOG_PATH = "/tmp/runtime_combined.log"
COMBINED_LOG_START_TS_PATH = "/tmp/runtime_combined.start_ts"


def _combined_log_start_ts():
    """Shared trial-start reference (same as attacker's helper)."""
    try:
        with open(COMBINED_LOG_START_TS_PATH) as f:
            return float(f.read().strip())
    except (FileNotFoundError, ValueError):
        t0 = time.time()
        try:
            with open(COMBINED_LOG_START_TS_PATH, "w") as f:
                f.write(f"{t0}\n")
        except Exception:
            pass
        return t0


def _combined_log(role, msg):
    import fcntl
    try:
        t0 = _combined_log_start_ts()
        with open(COMBINED_LOG_PATH, "a") as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            t = time.time() - t0
            f.write(f"[t={t:6.2f} {role:>8}] {msg}\n")
            f.flush()
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except Exception:
        pass


# When an effect alert fires, infer the foundation predicates that must have been set.
_FOUNDATION_BASE = [
    "credentialAccess_robot_host_",
    "attackerCanJoinRosGraph_robot_host_",
]

EFFECT_FOUNDATION_DEPS = {
    "drive_DoS_f1tenth_":           _FOUNDATION_BASE,
    "command_unsafe_f1tenth_":      _FOUNDATION_BASE,
    "scan_corrupted_f1tenth_":      _FOUNDATION_BASE,
    "scan_unreliable_f1tenth_":     _FOUNDATION_BASE + ["attackerCanNetAdmin_robot_host_"],
    "map_server_down_f1tenth_":     _FOUNDATION_BASE,
    "bridge_misconfigured_f1tenth_": _FOUNDATION_BASE,
    "data_leaked_f1tenth_":         _FOUNDATION_BASE,
}

# When a foundation alert fires, infer its upstream predicates so the strategy lookup matches.
FOUNDATION_PREDECESSORS = {
    "credentialAccess_robot_host_": [],
    "attackerCanJoinRosGraph_robot_host_": [
        "credentialAccess_robot_host_",
    ],
    "attackerCanNetAdmin_robot_host_": [],
}


# Order MUST match the `global ... : bool init false;` declarations in test.prism.
# L1 (canonical) is the default; LEVEL=2/3 overrides via attacker_config.json.
PRISM_VARS = [
    "systemCompromised_f1tenth_",
    "drive_DoS_f1tenth_",
    "attackerCanJoinRosGraph_robot_host_",
    "credentialAccess_robot_host_",
    "command_unsafe_f1tenth_",
    "scan_corrupted_f1tenth_",
    "scan_unreliable_f1tenth_",
    "attackerCanNetAdmin_robot_host_",
    "map_server_down_f1tenth_",
    "bridge_misconfigured_f1tenth_",
    "data_leaked_f1tenth_",
]


def _apply_level_prism_vars():
    """If LEVEL env var is set to 2/3, replace PRISM_VARS with the
    level-specific ordering RESIST emitted (15 entries at L2, 18 at L3).
    Must run before _strat_table_load() is called."""
    global PRISM_VARS
    level = os.environ.get("LEVEL", "1").strip()
    if level in ("", "1"):
        return
    cfg_path = (
        f"/home/f1tenth/finalVersion/experiment_runs/scalability/"
        f"level_{level}/attacker_config.json"
    )
    if not os.path.isfile(cfg_path):
        print(f"[defender] LEVEL={level} but no config at {cfg_path}; "
              f"using L1 PRISM_VARS")
        return
    import json as _json
    with open(cfg_path) as f:
        cfg = _json.load(f)
    pv = cfg.get("prism_vars")
    if pv:
        PRISM_VARS = list(pv)
        print(f"[defender] LEVEL={level}: replaced PRISM_VARS "
              f"with {len(PRISM_VARS)} entries from {cfg_path}")


_apply_level_prism_vars()



def _sh(cmd, timeout=10):
    print(f"[DEFENDER][CMD] {cmd}", flush=True)
    try:
        p = subprocess.run(
            ["bash", "-lc", cmd],
            capture_output=True, text=True, timeout=timeout,
        )
        out = ((p.stdout or "") + (p.stderr or "")).strip()
        if out:
            print(f"[DEFENDER][OUT rc={p.returncode}] {out[:500]}", flush=True)
        else:
            print(f"[DEFENDER][OUT rc={p.returncode}] <empty>", flush=True)
        return p
    except subprocess.TimeoutExpired:
        print("[DEFENDER][OUT] TIMEOUT", flush=True)
        return None


def _no_proc(pattern):
    """Return True when no running process matches `pattern` in its
    cmdline (substring match against /proc/<pid>/cmdline). Walks /proc
    directly so the shell that runs us isn't a self-match (the old
    `pgrep -f` approach mis-fired because the shell's argv contained
    `pgrep -f <pattern>`)."""
    import re
    rx = re.compile(pattern)
    self_pid = os.getpid()
    try:
        for entry in os.listdir("/proc"):
            if not entry.isdigit():
                continue
            pid = int(entry)
            if pid == self_pid:
                continue
            try:
                with open(f"/proc/{pid}/cmdline", "rb") as f:
                    raw = f.read()
            except (FileNotFoundError, PermissionError):
                continue
            # cmdline is nul-separated; join with spaces for regex match
            cmdline = raw.replace(b"\0", b" ").decode("utf-8", errors="ignore")
            if rx.search(cmdline):
                return False  # process still alive
        return True  # nothing matched
    except Exception:
        return False  # be safe: assume process still there on error


def _rc(p):
    """Pull a returncode out of a `_sh` result, tolerating timeout (None)."""
    return p.returncode if p is not None else 1


# Per-turn accumulator: the kill_pids_matching helper appends a dict for
# every process it kills, and _react() clears+reads this list to write the
# turn-summary JSON. Module-level because the defenses are free functions.
TURN_KILLS = []


def kill_pids_matching(pattern, description):
    """Find every process whose /proc/<pid>/cmdline matches `pattern`
    (regex, substring-search) and SIGKILL it. Skips the defender itself.
    Prints one line per kill so the log says exactly what got killed.
    Appends each kill to TURN_KILLS so _react() can write a structured
    turn summary for the attacker's unified narrative.
    Returns the count of processes killed.
    """
    rx = re.compile(pattern)
    self_pid = os.getpid()
    killed = 0
    for entry in os.listdir("/proc"):
        if not entry.isdigit():
            continue
        pid = int(entry)
        if pid == self_pid:
            continue
        try:
            with open(f"/proc/{pid}/cmdline", "rb") as f:
                raw = f.read()
        except (FileNotFoundError, PermissionError):
            continue
        cmdline = raw.replace(b"\0", b" ").decode("utf-8", errors="ignore").strip()
        if not cmdline:
            continue
        if rx.search(cmdline):
            try:
                os.kill(pid, 9)  # SIGKILL
                killed += 1
                TURN_KILLS.append({
                    "pid": pid,
                    "description": description,
                    "cmdline": cmdline[:120],
                })
                print(f"[DEFENDER] killed pid={pid} ({description}): "
                      f"{cmdline[:100]}", flush=True)
                _combined_log("DEFENDER", f"killed pid={pid} ({description})")
            except (ProcessLookupError, PermissionError) as e:
                print(f"[DEFENDER] could not kill pid={pid} ({description}): {e}",
                      flush=True)
    return killed


def sh(cmd, timeout=8):
    """Run a shell command, log it, return (rc, output)."""
    print(f"[DEFENDER] $ {cmd}", flush=True)
    try:
        p = subprocess.run(
            ["bash", "-lc", cmd],
            capture_output=True, text=True, timeout=timeout,
        )
        out = ((p.stdout or "") + (p.stderr or "")).strip()
        rc = p.returncode
    except subprocess.TimeoutExpired:
        out = "TIMEOUT"
        rc = 124
    if out:
        print(f"[DEFENDER]   rc={rc}  {out[:200]}", flush=True)
    else:
        print(f"[DEFENDER]   rc={rc}", flush=True)
    return rc, out


def _flush_stale_drive_command():
    """Reset gym_bridge to a safe drive command after killing a rogue publisher."""
    node = g_defender_node
    if node is None or node.drive_pub is None:
        return
    msg = AckermannDriveStamped()
    msg.drive.speed = 0.0
    msg.drive.steering_angle = 0.0
    for _ in range(4):            # 100 ms of zero-vel at 40 Hz
        node.drive_pub.publish(msg)
        time.sleep(0.025)


def def_kill_rogue_publishers():
    """Clears scan_corrupted AND drive_DoS. Sweep both /scan and /drive
    rogue publishers. Includes the rclpy-script attackers
    (attacker_drive_writer, attacker_drive_flooder, attacker_scan_writer,
    attacker_scan_corrupter, attacker_qos_degrader). The physical brake
    happens via the post-strategy def_safe_drive_override block in
    _handle_alert_inline; no in-function brake here (concurrent flushes
    were stacking to ~1200 Hz on /drive and tripping the monitor's own
    REQ_drive_DoS guard)."""
    a = kill_pids_matching(r"ros2 topic pub.*/scan", "rogue /scan ros2-cli publisher")
    b = kill_pids_matching(r"ros2 topic pub.*/drive", "rogue /drive ros2-cli publisher")
    c = kill_pids_matching(r"attacker_drive_writer|attacker_drive_flooder",
                           "rogue /drive rclpy publisher")
    d = kill_pids_matching(r"attacker_scan_writer|attacker_scan_corrupter|attacker_qos_degrader",
                           "rogue /scan rclpy publisher")
    return (a + b + c + d) > 0


def def_block_scan_replay():
    """Counter MITM and stale-publish on /scan: kill the dual-role
    (pub+sub) attacker and the backdated-timestamp publisher."""
    a = kill_pids_matching(r"mitm_scan_attack", "MITM /scan attacker")
    b = kill_pids_matching(r"stale_publish_scan_attack", "stale /scan publisher")
    return (a + b) > 0


def def_restore_scan_quality():
    """Restore /scan reliability. Covers both paths to scan_unreliable:
    (a) DDS-side (QoS flip, rogue scan pubs) and (b) network-side
    (tc netem packet drop/delay).

    Two changes vs the previous version:
      * `sudo -n` is non-interactive — if NOPASSWD isn't configured
        the command fails fast (rc != 0) instead of hanging on a
        password prompt that gets swallowed by `2>/dev/null`. No
        more `|| true` masking a silent no-op.
      * A REAL fallback for when sudo is blocked: pkill the
        attacker's tc-installer script processes so the qdisc
        can't be re-installed on the next attacker turn."""
    # DDS side
    a = kill_pids_matching(r"reliability_flip_scan_attack|attacker_qos_degrader",
                           "QoS-flip/degrader attacker")
    b = kill_pids_matching(r"ros2 topic pub.*/scan|attacker_scan_writer|attacker_scan_corrupter",
                           "rogue /scan publisher (best-effort QoS)")
    # Real fallback when sudo NOPASSWD isn't available: kill the
    # tc-installer script so the attacker can't re-add the qdisc.
    c = kill_pids_matching(
        r"attacker_netadmin_topicdrop|attacker_netadmin_topicdelay|tc\s+qdisc\s+add",
        "tc-installer attacker script")
    # Network side: clear any tc qdisc the attacker installed.
    # Physical brake comes from the post-strategy safety block in
    # _handle_alert_inline, single-instance + locked. No in-function
    # flush here to avoid stacking concurrent /drive publishers.
    cleared = 0
    for iface in ("lo", "eth0", "wlan0"):
        rc, _ = sh(f"sudo -n tc qdisc del dev {iface} root")
        if rc == 0:
            cleared += 1
    return (a + b + c) > 0 or cleared > 0


def def_kill_rogue_subscribers():
    """Clears data_leaked. Kill rogue subscribers on /scan and /odom and
    the cross-topic correlator. Includes the rclpy-script attackers
    (attacker_scan_reader, attacker_odom_reader)."""
    a = kill_pids_matching(r"ros2 topic echo.*/scan",
                           "rogue /scan ros2-cli subscriber")
    b = kill_pids_matching(r"ros2 topic echo.*/odom",
                           "rogue /odom ros2-cli subscriber")
    c = kill_pids_matching(r"attacker_scan_reader|attacker_odom_reader",
                           "rogue rclpy exfil subscriber")
    d = kill_pids_matching(r"cross_topic_correlation_attack",
                           "cross-topic correlator")
    return (a + b + c + d) > 0


def def_revert_node_parameters():
    """Clears bridge_misconfigured and the parameter-tamper path to
    map_server_down. Fire SetParameters requests asynchronously to
    revert use_sim_time on /bridge and /map_server.

    Implementation detail: we DO NOT block waiting for the service
    reply. This function is called from inside an alert subscription
    callback that is already running under rclpy.spin(node), so
    rclpy.spin_until_future_complete here would be a nested spin of
    the same executor — that pattern is unsafe in ROS 2 Foxy with the
    single-threaded executor and crashes the process when both
    services time out. We fire-and-forget; the reply is processed by
    the main spin loop once the alert callback returns."""
    node = g_defender_node
    if node is None:
        print("[DEFENDER] def_revert_node_parameters: g_defender_node not set", flush=True)
        return False
    ok = False
    for cli, name in ((node.set_param_cli_bridge, "/bridge"),
                      (node.set_param_cli_map,    "/map_server")):
        if not cli.service_is_ready():
            print(f"[DEFENDER] def_revert_node_parameters: {name}/set_parameters "
                  f"not ready, skipping", flush=True)
            continue
        req = SetParameters.Request()
        p = Parameter()
        p.name = "use_sim_time"
        p.value.type = ParameterType.PARAMETER_BOOL
        p.value.bool_value = False
        req.parameters = [p]
        cli.call_async(req)
        ok = True
        print(f"[DEFENDER] reset use_sim_time on {name} (async, no wait)", flush=True)
    return ok


def def_reactivate_map_server():
    """Clears map_server_down. Publishes a forged TransitionEvent
    showing /map_server transitioning back to ACTIVE
    (start=INACTIVE -> goal=ACTIVE via ACTIVATE, id 3).

    Implementation mirrors the attacker's lifecycle-hijack spoof:
    both sides bypass the Foxy SROS2 /map_server/change_state
    service discovery (which times out under enforcement) by
    talking directly to the /map_server/transition_event topic
    the monitor inspects to decide REQ_map_server_down. The
    monitor's `map_server_state` field tracks `goal_state.id` of
    the latest event; publishing id=3 (ACTIVE) resets it and
    clears the alert latch."""
    node = g_defender_node
    if node is None or node.transition_event_pub is None:
        print("[DEFENDER] def_reactivate_map_server: transition_event_pub not initialised",
              flush=True)
        return False
    ev = TransitionEvent()
    ev.timestamp = int(time.time() * 1e9)
    ev.transition.id = 3
    ev.transition.label = "activate"
    ev.start_state.id = 2
    ev.start_state.label = "inactive"
    ev.goal_state.id = 3
    ev.goal_state.label = "active"
    # Publish twice with a short gap to ride out any pub/sub
    # discovery handshake race.
    node.transition_event_pub.publish(ev)
    time.sleep(0.2)
    node.transition_event_pub.publish(ev)
    print("[DEFENDER] def_reactivate_map_server: published forged ACTIVATE event "
          "(inactive -> active) to /map_server/transition_event", flush=True)
    return True


# Single-instance brake state. Monitor republishes the alert every 20 ms,
# so without this guard we'd spawn ~75 brake threads per 1.5 s attack and
# the car would visibly stutter. Instead: the brake runs ONE thread at a
# time, and incoming alerts just bump the deadline (auto-extend).
_safe_drive_lock = threading.Lock()
_safe_drive_end_ts = [0.0]   # mutable container so closure can update it
_safe_drive_running = [False]

def def_safe_drive_override():
    """Single-instance physical brake. First call spins up the publish
    loop; concurrent calls just extend the end-time so the brake holds
    as long as alerts keep arriving.

    1.5 s default; bridge holds last command forever so the loop must
    keep publishing zero-velocity to keep the car stopped while the
    attacker is still spamming /drive.
    """
    node = g_defender_node
    if node is None or node.drive_pub is None:
        print("[DEFENDER] def_safe_drive_override: drive_pub not initialised", flush=True)
        return False
    BRAKE_DURATION = 1.5
    now = time.time()
    # Bump the deadline (auto-extend) under lock.
    with _safe_drive_lock:
        new_end = now + BRAKE_DURATION
        if new_end > _safe_drive_end_ts[0]:
            _safe_drive_end_ts[0] = new_end
        if _safe_drive_running[0]:
            return True   # existing loop will see the extended deadline
        _safe_drive_running[0] = True

    msg = AckermannDriveStamped()
    msg.drive.speed = 0.0
    msg.drive.steering_angle = 0.0
    count = 0
    try:
        while time.time() < _safe_drive_end_ts[0]:
            node.drive_pub.publish(msg)
            count += 1
            time.sleep(0.025)  # 40 Hz — below monitor's REQ_drive_DoS guard
    finally:
        with _safe_drive_lock:
            _safe_drive_running[0] = False
    print(f"[DEFENDER] def_safe_drive_override: published {count} zero-velocity msgs "
          f"(single-instance, auto-extend)", flush=True)
    return count > 0


def def_isolate_breached_host():
    """D3-EI. Clears initialAccess."""
    a = kill_pids_matching(r"attacker_engineering_ws_compromised",
                           "engineering_ws foothold")
    b = kill_pids_matching(r"attacker_initial_access",
                           "initial-access marker")
    return (a + b) > 0


def def_block_lateral_movement():
    """D3-NTF. Clears lateralAccess."""
    return kill_pids_matching(r"attacker_lateral",
                              "lateral-movement marker") > 0


def def_rotate_credentials():
    """D3-RUAA. Nuke stolen keystore, kill creds marker, clear credentialAccess."""
    killed = kill_pids_matching(r"attacker_creds_obtained", "stolen-creds marker")

    stolen_path = "/tmp/stolen_ros_keystore"
    nuked_stolen = False
    if os.path.isdir(stolen_path):
        rc, _ = sh(f"rm -rf {stolen_path}")
        if rc == 0:
            nuked_stolen = True
            print(f"[DEFENDER] nuked stolen keystore at {stolen_path}", flush=True)

    # Legacy marker file
    try:
        os.remove("/tmp/stolen_ros_creds")
        removed_file = True
    except FileNotFoundError:
        removed_file = False

    print("[DEFENDER] credentials rotated; stolen keys invalidated", flush=True)
    return killed > 0 or nuked_stolen or removed_file


# Per-defense reliability values match the corresponding `0.XX:` branches in test.prism.
DEFENSE_RELIABILITY = {
    "def_kill_rogue_publishers":   0.92,
    "def_kill_rogue_subscribers":  0.90,
    "def_block_scan_replay":       0.85,
    "def_restore_scan_quality":    0.85,
    "def_revert_node_parameters":  0.92,
    "def_reactivate_map_server":   0.95,
    "def_safe_drive_override":     0.90,
    "def_rotate_credentials":      0.90,
}


DEFENSES = {
    "def_kill_rogue_publishers": (
        def_kill_rogue_publishers,
        ["scan_corrupted_f1tenth_", "drive_DoS_f1tenth_"],
    ),
    "def_block_scan_replay": (
        def_block_scan_replay,
        ["scan_corrupted_f1tenth_"],
    ),
    "def_restore_scan_quality": (
        def_restore_scan_quality,
        ["scan_unreliable_f1tenth_"],
    ),
    "def_kill_rogue_subscribers": (
        def_kill_rogue_subscribers,
        ["data_leaked_f1tenth_"],
    ),
    "def_revert_node_parameters": (
        def_revert_node_parameters,
        ["bridge_misconfigured_f1tenth_", "map_server_down_f1tenth_"],
    ),
    "def_reactivate_map_server": (
        def_reactivate_map_server,
        ["map_server_down_f1tenth_"],
    ),
    "def_safe_drive_override": (
        def_safe_drive_override,
        ["command_unsafe_f1tenth_"],
    ),
    "def_rotate_credentials": (
        def_rotate_credentials,
        ["credentialAccess_robot_host_", "attackerCanJoinRosGraph_robot_host_"],
    ),
}


DEFENSE_REVOKES = {
    "def_kill_rogue_publishers": [
        # Kills /scan rogue pubs + /drive flood. Drops the leaves on
        # both sides (scan content + drive flood). Drive's topicWrite
        # remains for safe_drive_override to handle (the override
        # drowns out, doesn't kill the publisher).
        "topicWrite('/scan')",
        "maliciousTopicContent('/scan')",
        "topicFlood('/drive')",
        "mitmPossible('/scan')",
        # L2 scalability extension: kills malicious /map publisher leaf
        # so the synth defender at L2 actually clears the precondition
        # that fires scan_corrupted via RULE51 on the new topic.
        "maliciousTopicContent('/map')",
        # EFFECT predicates this defense neutralises — MUST be in the
        # revoke list, otherwise once they're chain-derived into the
        # attacker's state.json they linger and the next chain
        # derivation fires sysC.
        "scan_corrupted(f1tenth)",
        "drive_DoS(f1tenth)",
    ],
    "def_block_scan_replay": [
        # Targets MITM + stale workers specifically. Dual-role kill
        # also breaks mitmPossible.
        "mitmInjection('/scan')",
        "stalePublish('/scan')",
        "mitmPossible('/scan')",
        # L2 scalability extension: MITM on /parameter_events leaf
        "mitmInjection('/parameter_events')",
        "scan_corrupted(f1tenth)",
    ],
    "def_restore_scan_quality": [
        "qosDegradation('/scan')",
        "reliabilityFlip('/scan')",
        "topicDrop('/scan')",
        "topicDelay('/scan')",
        "scan_unreliable(f1tenth)",
    ],
    "def_kill_rogue_subscribers": [
        "topicRead('/scan')",
        "topicRead('/odom')",
        "crossTopicCorrelation(f1tenth)",
        "exfiltrateChannel('/attacker_exfil')",
        "mitmPossible('/scan')",
        "cryptoInfoLeak('/scan')",
        "data_leaked(f1tenth)",
    ],
    "def_revert_node_parameters": [
        "serviceCall('/bridge/set_parameters',bridge)",
        "serviceCall('/map_server/set_parameters',map_server)",
        "parameterTamper(map_server)",
        "lifecycleHijack(map_server)",
        "bridge_misconfigured(f1tenth)",
        "map_server_down(f1tenth)",
    ],
    "def_reactivate_map_server": [
        "serviceCall('/map_server/change_state',map_server)",
        "lifecycleHijack(map_server)",
        "lifecycleAbuse(map_server)",
        "lifecycleDisruption(map_server)",
        "map_server_down(f1tenth)",
    ],
    "def_safe_drive_override": [
        "topicWrite('/drive')",
        "gradualDrift('/drive')",
        "arrayDosExploit(bridge,'/drive')",
        # L2 scalability extension: direct rogue writes to /cmd_vel and
        # /initialpose are the new leaves that feed drive_DoS /
        # command_unsafe at L2.
        "topicWrite('/cmd_vel')",
        "topicWrite('/initialpose')",
        "command_unsafe(f1tenth)",
        "drive_DoS(f1tenth)",
    ],
    "def_rotate_credentials": [
        "credentialAccess(robot_host)",
        "attackerCanJoinRosGraph(robot_host)",
        "topicWrite('/scan')",
        "topicWrite('/drive')",
        "topicRead('/scan')",
        "topicRead('/odom')",
        "topicFlood('/drive')",
        "maliciousTopicContent('/scan')",
        "qosDegradation('/scan')",
        "serviceCall('/bridge/set_parameters',bridge)",
        "serviceCall('/map_server/change_state',map_server)",
        "serviceCall('/map_server/set_parameters',map_server)",
        "cryptoInfoLeak('/scan')",
        "arrayDosExploit(bridge,'/drive')",
        # L2 scalability extension: rotating credentials invalidates
        # every authorized publisher capability, including the four new
        # L2 leaves on /cmd_vel, /initialpose, /map, /parameter_events.
        "topicWrite('/cmd_vel')",
        "topicWrite('/initialpose')",
        "maliciousTopicContent('/map')",
        "mitmInjection('/parameter_events')",
    ],
}


def revoke_attacker_predicates(defense_name):
    """Wait for the attacker to mark predicates, then revoke them."""
    preds = DEFENSE_REVOKES.get(defense_name, [])
    if not preds:
        return []

    POLL_TIMEOUT = 2.5   # seconds; covers slowest leaf subprocess (~2s) + slack
    POLL_INTERVAL = 0.05 # 50 ms

    deadline = time.time() + POLL_TIMEOUT
    state = None
    landed = False
    while time.time() < deadline:
        if not os.path.exists(ATTACKER_STATE_PATH):
            time.sleep(POLL_INTERVAL)
            continue
        try:
            with open(ATTACKER_STATE_PATH) as f:
                state = json.load(f)
        except Exception:
            time.sleep(POLL_INTERVAL)
            continue
        preds_now = state.get("predicates", {}) or {}
        if any(preds_now.get(p) for p in preds):
            landed = True
            break  # attacker has landed at least one — go revoke
        time.sleep(POLL_INTERVAL)

    # If the poll never saw the predicate, fall through to set the preemptive block anyway.
    if not landed:
        if state is None:
            try:
                with open(ATTACKER_STATE_PATH) as f:
                    state = json.load(f)
            except Exception:
                state = {"facts": {}, "predicates": {}, "smg": {"t": 1}, "meta": {}}

    state.setdefault("predicates", {})
    state.setdefault("meta", {})
    # blocked_predicates is a soft-lockout dict checked by mark_pred / propagate_derived.
    BLOCK_TTL_SEC = 5.0
    blocked = state["meta"].setdefault("blocked_predicates", {})
    revoked = []
    now = time.time()
    expiry = now + BLOCK_TTL_SEC
    for p in preds:
        blocked[p] = expiry
        if state["predicates"].pop(p, False):
            revoked.append(p)
            state["meta"][f"revoked_by_defender::{p}"] = (
                f"{defense_name}@{now:.3f}"
            )
            state["meta"].pop(f"why::{p}", None)

    # Atomic write (tmpfile + rename) so the attacker never sees a half-written file.
    try:
        tmp_path = f"{ATTACKER_STATE_PATH}.tmp.{os.getpid()}"
        with open(tmp_path, "w") as f:
            json.dump(state, f, indent=2, sort_keys=True)
        os.replace(tmp_path, ATTACKER_STATE_PATH)
        if revoked:
            print(f"[DEFENDER] ✓ REVOKED {revoked} — predicate(s) cleared from state.json",
                  flush=True)
            _combined_log("DEFENDER",
                f"REVOKED {revoked} (predicates removed from state.json)")
        else:
            print(f"[DEFENDER] ✓ REVOKED {preds} — locked out via blocked_predicates "
                  f"(TTL={BLOCK_TTL_SEC}s, attacker can't mark in next step)",
                  flush=True)
            _combined_log("DEFENDER",
                f"REVOKED {preds} (preemptive lockout — attacker hadn't marked yet)")
    except Exception as e:
        print(f"[DEFENDER] could not write state.json: {e}", flush=True)
    return list(preds)


# PRISM-games strategy lines: (b1,b2,...,bN,t)=action with bN = "true"/"false".
_STRAT_RE = re.compile(r"^\(([^)]+)\)=(.*)$")


def _prism_vars_hash():
    """SHA256 of PRISM_VARS ordering, used as a lock-step check against the strategy file."""
    import hashlib
    blob = "\n".join(PRISM_VARS).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()[:16]


def parse_strategy(path):
    table = {}
    n_vars = len(PRISM_VARS)
    skipped = 0
    expected_hash = _prism_vars_hash()
    file_hash = None
    with open(path) as f:
        for line in f:
            stripped = line.strip()
            if stripped.startswith("#"):
                m_hash = re.search(r"vars_sha256:\s*([0-9a-f]{8,})", stripped)
                if m_hash:
                    file_hash = m_hash.group(1)[:16]
                continue
            m = _STRAT_RE.match(stripped)
            if not m:
                continue
            tup_str, action = m.group(1), m.group(2).strip()
            parts = [p.strip() for p in tup_str.split(",")]
            if len(parts) != n_vars + 1:
                skipped += 1
                continue
            try:
                bits = tuple(p.lower() == "true" for p in parts[:-1])
                t = int(parts[-1])
            except ValueError:
                skipped += 1
                continue
            table[bits + (t,)] = action

    if file_hash is None:
        print(f"[defender] WARNING: strategy file has no vars_sha256 header "
              f"(expected hash={expected_hash}); skipping verification. "
              f"Add `# vars_sha256: {expected_hash}` to {path} line 1 "
              f"to enable lock-step checking.")
    elif file_hash != expected_hash:
        raise RuntimeError(
            f"strategy file PRISM_VARS hash mismatch: "
            f"file={file_hash}, expected={expected_hash}. "
            f"Either Strat.txt was generated against a different model, "
            f"or PRISM_VARS in defender_agent.py is out of date. "
            f"Regenerate Strat.txt or align PRISM_VARS before continuing."
        )
    else:
        print(f"[defender] PRISM_VARS hash verified ({expected_hash})")

    print(f"[defender] loaded {len(table)} strategy entries from {path}"
          f" (skipped {skipped})")
    return table


class DefenderNode(Node):
    def __init__(self, strategy):
        super().__init__("defender_agent")
        self.strategy = strategy
        self.state = {v: False for v in PRISM_VARS}
        self._last_acted = {v: 0.0 for v in PRISM_VARS}
        # TRANSIENT_LOCAL catches alerts fired before this subscription was ready.
        _alerts_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            history=HistoryPolicy.KEEP_LAST,
            depth=1000,
        )
        self.sub = self.create_subscription(
            String, "/monitor_alerts", self.on_alert, _alerts_qos,
        )
        self.drive_pub = self.create_publisher(
            AckermannDriveStamped, "/drive", 10,
        )
        self.set_param_cli_bridge = self.create_client(
            SetParameters, "/bridge/set_parameters")
        self.set_param_cli_map = self.create_client(
            SetParameters, "/map_server/set_parameters")
        self.change_state_cli_map = self.create_client(
            ChangeState, "/map_server/change_state")
        # Publishes forged ACTIVATE events to /map_server/transition_event for def_reactivate_map_server.
        self.transition_event_pub = self.create_publisher(
            TransitionEvent, "/map_server/transition_event",
            QoSProfile(reliability=ReliabilityPolicy.RELIABLE,
                       durability=DurabilityPolicy.TRANSIENT_LOCAL,
                       history=HistoryPolicy.KEEP_LAST, depth=1))
        global g_defender_node
        g_defender_node = self

        self._post_hoc_queue = []
        self._pending_alerts = set()
        # Ignore alerts/step-done until the attacker has signalled at least one step-done this trial.
        self._first_attacker_step_seen = False
        self._queue_lock = threading.Lock()
        self._watcher_stop = threading.Event()
        self._watcher = threading.Thread(
            target=self._step_done_watcher, daemon=True
        )
        self._watcher.start()

        self.get_logger().info(
            "defender_agent ready, listening on /monitor_alerts"
            " (post-hoc queue active)"
        )

    def _step_done_watcher(self):
        last_step_done_mtime = 0.0
        while not self._watcher_stop.is_set():
            try:
                step_done_mtime = os.stat(ATTACKER_STEP_DONE_PATH).st_mtime
            except FileNotFoundError:
                step_done_mtime = 0.0

            if step_done_mtime > last_step_done_mtime:
                last_step_done_mtime = step_done_mtime
                if not self._first_attacker_step_seen:
                    with self._queue_lock:
                        if self._pending_alerts:
                            self.get_logger().info(
                                f"trial-isolation: discarding "
                                f"{len(self._pending_alerts)} pre-trial "
                                f"alert(s): {sorted(self._pending_alerts)}"
                            )
                            self._pending_alerts.clear()
                    self._first_attacker_step_seen = True
                # SIGUSR1 the monitor to reset alert latches.
                try:
                    subprocess.run(
                        ["pkill", "-SIGUSR1", "-f", "system_monitor_node"],
                        check=False, timeout=2,
                    )
                except Exception:
                    pass
                # Wait 2s for the monitor to detect + publish alerts (covers /scan smoothing window).
                time.sleep(2.0)
                self._defender_turn()
            time.sleep(0.02)

    def _defender_turn(self):
        """Drain pending alerts into state, run one strategy lookup, play one defense."""
        with self._queue_lock:
            drained = set(self._pending_alerts)
            self._pending_alerts.clear()
            # Also drain any alerts that were post-hoc queued (legacy
            # code paths may still push here, e.g. if external code
            # appends to the queue).
            for alert, _qa in self._post_hoc_queue:
                drained.add(alert)
            self._post_hoc_queue = []
        # Stash for the per-turn JSON summary the attacker reads.
        self._drained_this_turn = set(drained)

        # Update state from this turn's accumulated alerts.
        for alert in drained:
            var = ALERT_TO_VAR.get(alert)
            if var is None:
                continue
            if not self.state[var]:
                self.state[var] = True
                self.get_logger().info(
                    f"turn drain: {alert} -> {var}=True"
                )
                # Inference 1: for EFFECT alerts, set foundation chain.
                for foundation_var in EFFECT_FOUNDATION_DEPS.get(var, []):
                    if (foundation_var in self.state
                            and not self.state[foundation_var]):
                        self.state[foundation_var] = True
                        self.get_logger().info(
                            f"inferred foundation: {foundation_var}=True "
                            f"(precondition of {var})"
                        )
                # Inference 2: for FOUNDATION alerts, set upstream.
                for upstream in FOUNDATION_PREDECESSORS.get(var, []):
                    if (upstream in self.state
                            and not self.state[upstream]):
                        self.state[upstream] = True
                        self.get_logger().info(
                            f"inferred upstream: {upstream}=True "
                            f"(predecessor of {var})"
                        )

        # If nothing has ever been violated, skip the turn entirely.
        if not any(self.state[v] for v in self.state
                   if v != "t" and isinstance(self.state.get(v), bool)):
            return

        self._current_alert = next(iter(drained)) if drained else None
        self._print_state(prefix="defender turn pre-strategy")
        self._react()

    def _print_state(self, prefix=""):
        # Hand-tuned short names so scan_corrupted and scan_unreliable
        # don't both collapse to "scan=F,scan=F" (the previous behaviour
        # of `v.split("_")[0]`).
        SHORT = {
            "drive_DoS_f1tenth_":                 "driveDoS",
            "command_unsafe_f1tenth_":            "cmdUnsafe",
            "scan_corrupted_f1tenth_":            "scanCorr",
            "scan_unreliable_f1tenth_":           "scanUnrel",
            "map_server_down_f1tenth_":           "mapDown",
            "bridge_misconfigured_f1tenth_":      "bridgeMis",
            "data_leaked_f1tenth_":               "dataLeak",
            "initialAccess_engineering_ws_":      "initAcc",
            "lateralAccess_robot_host_":          "latAcc",
            "credentialAccess_robot_host_":       "credAcc",
            "attackerOnRosNetwork_robot_host_":   "onROSNet",
            "attackerCanJoinRosGraph_robot_host_": "joinGraph",
            "attackerCanNetAdmin_robot_host_":    "netAdmin",
        }
        flags = ",".join(
            SHORT.get(v, v) + ("=T" if self.state[v] else "=F")
            for v in PRISM_VARS[1:]
        )
        self.get_logger().info(f"{prefix} state: {flags}")

    def on_alert(self, msg):
        # Accumulate; the actual turn runs from _step_done_watcher.
        alert = msg.data.split(":", 1)[0].strip()
        var = ALERT_TO_VAR.get(alert)
        if var is None:
            self.get_logger().warn(f"unknown alert {alert!r}; ignored")
            return
        if var not in self.state:
            # PRISM_VARS at this LEVEL doesn't track this predicate (e.g.
            # at L0, data_leaked is dropped from the SMG). The monitor still
            # emits the alert for the canonical L1 schema; ignore it here.
            return
        if self.state[var]:
            return
        with self._queue_lock:
            if alert not in self._pending_alerts:
                self._pending_alerts.add(alert)
                self.get_logger().info(
                    f"alert {alert} added to pending set "
                    f"(will fire on next attacker step-done)"
                )
                _combined_log("DEFENDER", f"queued {alert} (turn-based)")

    def _handle_alert_inline(self, alert):
        """Set the bit, cascade foundation, and run the defense."""
        var = ALERT_TO_VAR.get(alert)
        if var is None:
            return
        now = time.time()
        if now - self._last_acted[var] < ALERT_COOLDOWN_SEC:
            return
        if self.state[var]:
            return
        self.state[var] = True
        self._current_alert = alert
        self.get_logger().info(f"alert {alert} -> {var}=True")
        for foundation_var in EFFECT_FOUNDATION_DEPS.get(var, []):
            if foundation_var in self.state and not self.state[foundation_var]:
                self.state[foundation_var] = True
                self.get_logger().info(
                    f"inferred foundation: {foundation_var}=True "
                    f"(precondition of {var})"
                )
        for upstream in FOUNDATION_PREDECESSORS.get(var, []):
            if upstream in self.state and not self.state[upstream]:
                self.state[upstream] = True
                self.get_logger().info(
                    f"inferred upstream: {upstream}=True (predecessor of {var})"
                )
        self._print_state(prefix="post-alert")
        self._react()

        # Safety override on REQ_can_net_admin: the strategy has no direct counter for it.
        if alert == "REQ_can_net_admin":
            try:
                def_restore_scan_quality()
                _combined_log("DEFENDER",
                    "safety override on REQ_can_net_admin: "
                    "def_restore_scan_quality (clears tc qdisc + blocks scan_unreliable)")
                revoke_attacker_predicates("def_restore_scan_quality")
            except Exception as e:
                self.get_logger().warn(f"safety override failed: {e}")

        # Physical-safety override on drive/scan channel alerts: brake the car.
        if alert in ("REQ_drive_DoS", "REQ_command_unsafe",
                     "REQ_scan_unreliable", "REQ_scan_corrupted"):
            try:
                def_safe_drive_override()
                _combined_log("DEFENDER",
                    f"post-strategy hygiene on {alert}: "
                    f"def_safe_drive_override (200 Hz zero-velocity to /drive — car brakes)")
            except Exception as e:
                self.get_logger().warn(f"post-strategy brake failed: {e}")

    def _publish_turn_complete(self, action_taken=None):
        """File-based barrier; the file-polling attacker reads this to know the turn is done."""
        try:
            with open(TURN_COMPLETE_PATH, "w") as f:
                f.write(f"{time.time()}\n{action_taken or 'noop'}\n")
        except Exception as e:
            self.get_logger().warn(f"could not write turn-complete flag: {e}")

    def _react(self):
        action_taken = None
        revoked_list = []
        defense_succeeded = False
        TURN_KILLS.clear()
        try:
            policy = os.environ.get("DEFENDER_POLICY", "synth").strip().lower()
            if policy == "none":
                return
            bits = tuple(self.state[v] for v in PRISM_VARS)
            key = bits + (2,)
            bits_str = ",".join("true" if b else "false" for b in bits)
            strat_key_str = f"({bits_str},2)"
            named_state = ", ".join(
                f"{PRISM_VARS[i]}={'T' if bits[i] else 'F'}"
                for i in range(len(PRISM_VARS))
            )
            self.get_logger().info(
                f"strategy lookup state={named_state}"
            )
            self.get_logger().info(
                f"strategy lookup Strat.txt key={strat_key_str}"
            )
            _combined_log("DEFENDER",
                          f"strategy lookup state={named_state}")
            _combined_log("DEFENDER",
                          f"strategy lookup Strat.txt key={strat_key_str}")
            if policy == "random":
                import random as _rsel
                action = _rsel.choice(list(DEFENSES.keys()))
            else:
                action = self.strategy.get(key)
            if action is None:
                self.get_logger().warn(
                    f"no strategy entry for state tuple {key}; skipping"
                )
                _combined_log("DEFENDER",
                              f"NO MATCH for key={strat_key_str} in Strat.txt; skipping")
                return
            if not action.startswith("def_"):
                self.get_logger().warn(
                    f"strategy returned non-defense {action!r} at t=2; skipping"
                )
                return
            fn, clears = DEFENSES.get(action, (None, []))
            if fn is None:
                self.get_logger().warn(f"unknown defense {action!r}; skipping")
                return
            action_taken = action
            self.get_logger().info(
                f"strategy says: {action} (matched {strat_key_str}={action}; clears {clears})"
            )
            _combined_log("DEFENDER",
                          f"strategy chose {action} (matched {strat_key_str}={action}; clears {clears})")
            # Reliability dice rolled first, independently of fn().
            import random as _r
            reliability = DEFENSE_RELIABILITY.get(action, 0.90)
            rdice = _r.random()
            defense_succeeded = (rdice < reliability)

            if not defense_succeeded:
                self.get_logger().warn(
                    f"defense {action} reliability dice FAILED "
                    f"({rdice:.3f} >= {reliability:.2f}); skipping mechanism"
                )
                _combined_log("DEFENDER",
                              f"defense {action} reliability dice FAILED "
                              f"({rdice:.3f} >= {reliability:.2f})")
                defense_real = False
            else:
                _combined_log("DEFENDER",
                              f"defense {action} reliability dice OK "
                              f"({rdice:.3f} < {reliability:.2f})")
                try:
                    defense_real = bool(fn())
                except Exception as e:
                    self.get_logger().error(f"defense {action} raised: {e}")
                    _combined_log("DEFENDER", f"defense {action} RAISED: {e}")
                    defense_real = False

            if defense_succeeded:
                now = time.time()
                for v in clears:
                    self.state[v] = False
                    self._last_acted[v] = now
                revoked_list = revoke_attacker_predicates(action) or []
                if revoked_list:
                    self.get_logger().info(
                        f"sent attacker back: revoked {len(revoked_list)} predicate(s)"
                    )
            else:
                _combined_log("DEFENDER", f"defense {action} did NOT succeed (no revoke)")
                self.get_logger().warn(
                    f"defense {action} did NOT succeed — leaving bits {clears} set"
                )
            self._print_state(prefix="post-defense")
        finally:
            # Write a structured turn-summary JSON the attacker reads to
            # build its unified narrative log. Cleared at start of each
            # _react so it represents ONE defender turn.
            try:
                strat_key_str_local = strat_key_str
            except NameError:
                strat_key_str_local = None
            try:
                named_state_local = named_state
            except NameError:
                named_state_local = None
            drained_for_turn = sorted(getattr(self, "_drained_this_turn", set()))
            summary = {
                "turn_ts": time.time(),
                "alert": getattr(self, "_current_alert", None),
                "drained_alerts": drained_for_turn,
                "defense": action_taken,
                "defense_succeeded": defense_succeeded,
                "killed": list(TURN_KILLS),
                "revoked": revoked_list,
                "perceived_state": named_state_local,
                "strat_key": strat_key_str_local,
            }
            try:
                with open("/tmp/defender_last_turn.json", "w") as f:
                    json.dump(summary, f, indent=2)
            except Exception as e:
                self.get_logger().warn(f"could not write defender_last_turn.json: {e}")
            # Signal turn-complete on EVERY exit path.
            self._publish_turn_complete(action_taken)


def main():
    if len(sys.argv) < 2:
        print("usage: defender_agent.py <path/to/Strat.txt>")
        sys.exit(1)
    strat_path = sys.argv[1]
    if not os.path.exists(strat_path):
        print(f"strategy file not found: {strat_path}")
        sys.exit(1)
    strategy = parse_strategy(strat_path)
    if not strategy:
        print("strategy file parsed to 0 entries - check PRISM_VARS order matches the .prism")
        sys.exit(1)

    rclpy.init()
    node = DefenderNode(strategy)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
