import sys, time, json
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from ackermann_msgs.msg import AckermannDriveStamped

window_sec = float(sys.argv[1])
out_path = sys.argv[2]

scan_n = 0
drive_n = 0

def on_scan(msg):
    global scan_n
    scan_n += 1

def on_drive(msg):
    global drive_n
    drive_n += 1

rclpy.init()
node = Node('perf_hz_observer')
node.create_subscription(LaserScan, '/scan', on_scan, 10)
node.create_subscription(AckermannDriveStamped, '/drive', on_drive, 10)

t0 = time.time()
while time.time() - t0 < window_sec:
    rclpy.spin_once(node, timeout_sec=0.05)
elapsed = time.time() - t0

with open(out_path, 'w') as f:
    json.dump({
        'window_sec': elapsed,
        'scan_n': scan_n,
        'scan_hz': scan_n / elapsed,
        'drive_n': drive_n,
        'drive_hz': drive_n / elapsed,
    }, f)

node.destroy_node()
rclpy.shutdown()
