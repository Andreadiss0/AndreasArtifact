import os, sys, csv, glob

ROOT = sys.argv[1] if len(sys.argv) > 1 else \
    "/home/f1tenth/finalVersion/experiment_runs/scalability"

# The Mac side writes this once it has run PRISM-games at each level.
# Schema: level, ag_nodes, ag_edges, smg_vars, smg_states,
#         mulval_build_sec, prism_build_sec, prism_synth_sec, peak_mem_mb
SYNTH_CSV = os.path.join(ROOT, "synth_metrics.csv")

def load_synth():
    if not os.path.exists(SYNTH_CSV):
        return {}
    rows = {}
    with open(SYNTH_CSV) as f:
        for r in csv.DictReader(f):
            rows[r["level"]] = r
    return rows

def load_runtime(level_dir):
    p = os.path.join(level_dir, "runtime_metrics.csv")
    if not os.path.exists(p): return {}
    out = {}
    with open(p) as f:
        for r in csv.reader(f):
            if len(r) >= 2 and r[0] != "metric":
                out[r[0]] = r[1]
    return out

synth = load_synth()

# Each level is a subdir of ROOT (level_0, level_1, …)
levels = sorted(d for d in os.listdir(ROOT)
                if os.path.isdir(os.path.join(ROOT, d)) and d.startswith("level"))

cols = ["level", "ag_nodes", "ag_edges", "smg_states",
        "mulval_build_sec", "prism_build_sec", "prism_synth_sec", "peak_mem_mb",
        "trials", "trial_dur_mean_std", "atk_steps_mean_std", "pmax_empirical"]

def get(d, k): return d.get(k, "—")
table = []
for lvl in levels:
    s = synth.get(lvl, {})
    r = load_runtime(os.path.join(ROOT, lvl))
    table.append({
        "level": lvl,
        "ag_nodes": get(s, "ag_nodes"),
        "ag_edges": get(s, "ag_edges"),
        "smg_states": get(s, "smg_states"),
        "mulval_build_sec": get(s, "mulval_build_sec"),
        "prism_build_sec":  get(s, "prism_build_sec"),
        "prism_synth_sec":  get(s, "prism_synth_sec"),
        "peak_mem_mb":      get(s, "peak_mem_mb"),
        "trials":             get(r, "n_trials"),
        "trial_dur_mean_std": get(r, "trial_duration_mean_std"),
        "atk_steps_mean_std": get(r, "attacker_steps_mean_std"),
        "pmax_empirical":     get(r, "pmax_empirical"),
    })

widths = [max(len(c), max((len(str(t.get(c, "—"))) for t in table), default=3)) for c in cols]
def line(vals): return "  ".join(str(v).ljust(w) for v, w in zip(vals, widths))
print(line(cols))
print(line(["-" * w for w in widths]))
for t in table: print(line([t.get(c, "—") for c in cols]))
