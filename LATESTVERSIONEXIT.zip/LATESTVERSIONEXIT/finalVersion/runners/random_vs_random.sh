#!/bin/bash
# Defender: random
# Attacker: random (uniform)
#
# Experiment 1 Random baseline (re-runnable).

set -u
TRIALS=${1:-100}
OUT_DIR=/home/f1tenth/finalVersion/experiment_runs/random_vs_random

export DEFENDER_POLICY=random
export ATTACKER_POLICY=random

echo "============================================================="
echo " random_vs_random : ${TRIALS} trials -> ${OUT_DIR}"
echo "============================================================="

if ! pgrep -f "gym_bridge" > /dev/null; then
  echo "ERROR: simulator not running. Start ~/run_sim.sh in terminal 1." >&2
  exit 1
fi
if ! pgrep -f "normal_driver" > /dev/null; then
  echo "WARNING: normal_driver not running. Results will not match Exp 1." >&2
fi

mkdir -p "$(dirname "$OUT_DIR")"
if [ -d "$OUT_DIR" ]; then
  mv "$OUT_DIR" "${OUT_DIR}.bak_$(date +%Y%m%d_%H%M%S)"
fi

~/run_trials.sh "${TRIALS}"
status=$?

if [ -d /home/f1tenth/finalVersion/trials ]; then
  mv /home/f1tenth/finalVersion/trials "$OUT_DIR"
  echo "Trial results: $OUT_DIR"
fi

exit "$status"
