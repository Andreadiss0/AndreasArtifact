#!/usr/bin/env python3
"""Per-trial correctness audit.

Reads attacker.log, monitor.log, alerts.log, defender.log, combined.log
from one trial directory and verifies:

  1. ALERT CORRECTNESS
     - Every attacker action that SHOULD fire an alert did fire one
       (within a 10 s window of the action).
     - Every alert that fired has a corresponding attacker action within
       a 10 s window before it (no bogus alerts from nowhere).
     - Every alert the monitor published reached the defender (no drops
       between the monitor's publish and the defender's on_alert).

  2. DEFENSE CORRECTNESS
     - Every defender strategy lookup's state tuple, when grepped
       against Strat.txt, returns the same prescribed defense the
       defender actually played.
     - No defender turns missed (one defender turn per attacker step
       once the chain has produced at least one alert).

Exits 0 if all checks pass, 1 if any anomaly. Prints a clean human-
readable report to stdout.

Usage:
    python3 audit_trial.py <trial_dir> [--strat /path/to/Strat.txt]
"""
from __future__ import annotations
import sys, os, re, argparse

# Expected alert per attacker action (only actions that observably
# trigger a monitor alert).
EXPECTED_ALERT = {
    "credentialAccess(robot_host)":                        "REQ_credential_access",
    "attackerCanJoinRosGraph(robot_host)":                 "REQ_can_join_ros_graph",
    "attackerCanNetAdmin(robot_host)":                     "REQ_can_net_admin",
    "maliciousTopicContent('/scan')":                      "REQ_scan_corrupted",
    "stalePublish('/scan')":                               "REQ_scan_corrupted",
    "mitmInjection('/scan')":                              "REQ_scan_corrupted",
    "topicWrite('/scan')":                                 "REQ_scan_corrupted",
    "topicDrop('/scan')":                                  "REQ_scan_unreliable",
    "topicDelay('/scan')":                                 "REQ_scan_unreliable",
    "qosDegradation('/scan')":                             "REQ_scan_unreliable",
    "reliabilityFlip('/scan')":                            "REQ_scan_unreliable",
    "topicFlood('/drive')":                                "REQ_drive_DoS",
    "topicWrite('/drive')":                                "REQ_command_unsafe",
    "gradualDrift('/drive')":                              "REQ_command_unsafe",
    "arrayDosExploit(bridge,'/drive')":                    "REQ_drive_DoS",
    "lifecycleHijack(map_server)":                         "REQ_map_server_down",
    "serviceCall('/map_server/change_state',map_server)":  "REQ_map_server_down",
    "serviceCall('/map_server/set_parameters',map_server)":"REQ_map_server_down",
    "serviceCall('/bridge/set_parameters',bridge)":        "REQ_bridge_misconfigured",
    "topicRead('/scan')":                                  "REQ_data_leaked",
    "topicRead('/odom')":                                  "REQ_data_leaked",
}

ACTION_WINDOW_S = 10.0   # how long after an action we'll accept its alert
ALERT_REVERSE_S = 15.0   # how long before an alert we'll look for an action


def parse_attacker_actions(path: str):
    """Returns [(t_rel_seconds, action_str, dice_result)] for SUCCESS actions
    only. Falls back to attacker.log format if combined.log not present."""
    out = []
    if not os.path.exists(path):
        return out
    # Combined.log format: [t=  X.YY ATTACKER] fired ACTION dice=Z p=W -> SUCCESS
    # Attacker.log format: [ATTACKER] fired ACTION dice=Z p=W -> SUCCESS
    pat_combined_success = re.compile(
        r"\[t=\s*([\d.]+)\s+ATTACKER\] fired (\S+\([^)]*\))"
        r".*?(?:-> SUCCESS|deterministic SUCCESS)"
    )
    pat_attacker_success = re.compile(
        r"\[ATTACKER\] fired (\S+\([^)]*\))"
        r".*?(?:-> SUCCESS|deterministic SUCCESS)"
    )
    step_counter = 0
    with open(path) as f:
        for line in f:
            m = pat_combined_success.search(line)
            if m:
                out.append((float(m.group(1)), m.group(2), "SUCCESS"))
                continue
            m = pat_attacker_success.search(line)
            if m:
                step_counter += 1
                out.append((float(step_counter), m.group(1), "SUCCESS"))
    return out


def parse_monitor_alerts(path: str):
    """Returns [(absolute_ts, REQ_name)] from monitor.log ALERT_CAUSE lines."""
    out = []
    if not os.path.exists(path):
        return out
    pat = re.compile(r"\[(\d+\.\d+)\].*ALERT_CAUSE\] (REQ_[a-z_]+)")
    with open(path) as f:
        for line in f:
            m = pat.search(line)
            if m:
                out.append((float(m.group(1)), m.group(2)))
    return out


def parse_defender_received(path: str):
    """Returns [(absolute_ts, REQ_name)] of alerts the defender added to
    pending (turn-based) or processed (legacy)."""
    out = []
    if not os.path.exists(path):
        return out
    pat1 = re.compile(r"\[(\d+\.\d+)\].*alert (REQ_[a-z_]+).*added to pending set")
    pat2 = re.compile(r"\[(\d+\.\d+)\].*alert (REQ_[a-z_]+) -> [a-z_]+=True")
    pat3 = re.compile(r"\[(\d+\.\d+)\].*alert (REQ_[a-z_]+) queued \(post-hoc")
    with open(path) as f:
        for line in f:
            m = pat1.search(line) or pat2.search(line) or pat3.search(line)
            if m:
                out.append((float(m.group(1)), m.group(2)))
    return out


def parse_defender_strategy_lookups(path: str):
    """Returns [(absolute_ts, strat_key_str, action_played, dice_result)] for
    every defender strategy lookup. dice_result is 'OK' or 'FAILED' or None
    if not seen."""
    out = []
    if not os.path.exists(path):
        return out
    # New audit log format:
    #   strategy lookup Strat.txt key=(false,...,2)
    #   strategy says: def_xxx (matched (false,...,2)=def_xxx; clears [...])
    #   defense def_xxx reliability dice OK (0.123 < 0.90)
    key_pat = re.compile(r"\[(\d+\.\d+)\].*strategy lookup Strat\.txt key=(\(.+\))")
    chose_pat = re.compile(r"strategy (?:chose|says:) (def_\S+) \(matched (\(.+\))=")
    dice_pat = re.compile(r"defense (def_\S+) reliability dice (OK|FAILED)")

    last_key = None
    last_action = None
    with open(path) as f:
        for line in f:
            m = key_pat.search(line)
            if m:
                last_key = (float(m.group(1)), m.group(2))
                last_action = None
                continue
            m = chose_pat.search(line)
            if m and last_key is not None:
                last_action = m.group(1)
                key_matched = m.group(2)
                # We'll fill dice_result on the next dice line
                out.append([last_key[0], last_key[1], last_action, None, key_matched])
                continue
            m = dice_pat.search(line)
            if m and out and out[-1][2] == m.group(1):
                out[-1][3] = m.group(2)
    return out


def load_strat_table(strat_path: str):
    """Returns dict {strat_key_str: prescribed_action}."""
    table = {}
    if not os.path.exists(strat_path):
        return table
    line_pat = re.compile(r"(\([^)]+\))=(\S+)")
    with open(strat_path) as f:
        for line in f:
            m = line_pat.match(line.strip())
            if m:
                table[m.group(1)] = m.group(2)
    return table


def find_first_attacker_ts_offset(attacker_path: str, monitor_path: str):
    """Compute approximate offset (absolute_ts of t=0)."""
    # Use the first monitor.log timestamp as approximate trial start.
    if not os.path.exists(monitor_path):
        return None
    with open(monitor_path) as f:
        for line in f:
            m = re.match(r"\[INFO\] \[(\d+\.\d+)\]", line)
            if m:
                return float(m.group(1))
    return None


def audit(trial_dir: str, strat_path: str) -> dict:
    monitor_path  = os.path.join(trial_dir, "monitor.log")
    attacker_path = os.path.join(trial_dir, "attacker.log")
    defender_path = os.path.join(trial_dir, "defender.log")
    combined_path = os.path.join(trial_dir, "combined.log")

    actions = parse_attacker_actions(combined_path)
    if not actions:
        actions = parse_attacker_actions(attacker_path)
    monitor_alerts = parse_monitor_alerts(monitor_path)
    defender_received = parse_defender_received(defender_path)
    strategy_lookups = parse_defender_strategy_lookups(defender_path)
    strat_table = load_strat_table(strat_path)

    # Establish a trial-start absolute timestamp from monitor.log.
    t0_abs = find_first_attacker_ts_offset(attacker_path, monitor_path)

    report = {
        "trial_dir": trial_dir,
        "n_actions": len(actions),
        "n_monitor_alerts": len(monitor_alerts),
        "n_defender_received": len(defender_received),
        "n_strategy_lookups": len(strategy_lookups),
        "missing_alerts": [],   # attacker action with no matching alert
        "bogus_alerts": [],     # monitor alert with no matching action
        "dropped_alerts": [],   # monitor fired but defender didn't receive
        "wrong_defenses": [],   # defender played != Strat.txt prescription
        "no_strat_match": [],   # state key not in Strat.txt
    }

    # --- Check 1: every action with EXPECTED_ALERT got that alert ---
    # Convert action relative t= to absolute ts via t0_abs.
    for t_rel, action, _ in actions:
        expected = EXPECTED_ALERT.get(action)
        if expected is None:
            continue
        if t0_abs is None:
            continue
        act_abs = t0_abs + t_rel
        # Look for matching alert within ACTION_WINDOW_S after act_abs
        found = False
        for (a_ts, a_req) in monitor_alerts:
            if a_req == expected and act_abs - 1.0 <= a_ts <= act_abs + ACTION_WINDOW_S:
                found = True
                break
        if not found:
            report["missing_alerts"].append(
                {"t_rel": t_rel, "action": action, "expected": expected}
            )

    # --- Check 2: every monitor alert has a recent action that justifies it ---
    inverse_map = {}  # REQ -> set of actions that can produce it
    for act, req in EXPECTED_ALERT.items():
        inverse_map.setdefault(req, set()).add(act)
    if t0_abs is not None:
        action_abs = [(t0_abs + t, act) for (t, act, _) in actions]
        for (a_ts, a_req) in monitor_alerts:
            justifiers = inverse_map.get(a_req, set())
            if not justifiers:
                # Some alerts (REQ_can_net_admin, REQ_can_join_ros_graph)
                # are foundation alerts that the monitor infers from
                # observed system state, not from a specific attacker
                # action. Skip the justification check for those.
                continue
            justified = any(
                act in justifiers and (a_ts - ALERT_REVERSE_S) <= act_ts <= (a_ts + 1.0)
                for (act_ts, act) in action_abs
            )
            if not justified:
                report["bogus_alerts"].append({"alert_ts": a_ts, "alert": a_req})

    # --- Check 3: every monitor alert reached the defender ---
    received_counts = {}
    for _, req in defender_received:
        received_counts[req] = received_counts.get(req, 0) + 1
    monitor_counts = {}
    for _, req in monitor_alerts:
        monitor_counts[req] = monitor_counts.get(req, 0) + 1
    for req, mcount in monitor_counts.items():
        rcount = received_counts.get(req, 0)
        if rcount == 0 and mcount > 0:
            report["dropped_alerts"].append(
                {"alert": req, "monitor_published": mcount, "defender_received": 0}
            )

    # --- Check 4: every strategy lookup's prescribed action matches Strat.txt ---
    for entry in strategy_lookups:
        ts, key, action, dice, key_matched = entry
        if not strat_table:
            break
        prescribed = strat_table.get(key)
        if prescribed is None:
            report["no_strat_match"].append({"ts": ts, "key": key})
        elif prescribed != action:
            report["wrong_defenses"].append(
                {"ts": ts, "key": key, "played": action, "prescribed": prescribed}
            )

    report["healthy"] = (
        not report["missing_alerts"]
        and not report["bogus_alerts"]
        and not report["dropped_alerts"]
        and not report["wrong_defenses"]
        and not report["no_strat_match"]
    )
    return report


def print_report(r):
    print(f"=== Audit: {r['trial_dir']} ===")
    print(f"  attacker actions (SUCCESS):     {r['n_actions']}")
    print(f"  monitor alerts published:       {r['n_monitor_alerts']}")
    print(f"  defender alerts received:       {r['n_defender_received']}")
    print(f"  defender strategy lookups:      {r['n_strategy_lookups']}")
    print()

    if r["missing_alerts"]:
        print(f"  ❌ MISSING ALERTS ({len(r['missing_alerts'])}):")
        for x in r["missing_alerts"]:
            print(f"     t={x['t_rel']:.2f}  action={x['action']}  "
                  f"expected={x['expected']} (no alert fired in window)")
    else:
        print(f"  ✓ Every observable attacker action had its alert fire.")

    if r["bogus_alerts"]:
        print(f"  ❌ BOGUS ALERTS (no matching action) ({len(r['bogus_alerts'])}):")
        for x in r["bogus_alerts"][:10]:
            print(f"     ts={x['alert_ts']:.2f}  alert={x['alert']}  "
                  f"(no attacker action found in {ALERT_REVERSE_S}s before)")
        if len(r["bogus_alerts"]) > 10:
            print(f"     ... and {len(r['bogus_alerts'])-10} more")
    else:
        print(f"  ✓ Every alert had a recent justifying attacker action.")

    if r["dropped_alerts"]:
        print(f"  ❌ DROPPED ALERTS (monitor fired but defender never saw):")
        for x in r["dropped_alerts"]:
            print(f"     {x['alert']}  monitor_published={x['monitor_published']}  "
                  f"defender_received=0")
    else:
        print(f"  ✓ Every monitor alert reached the defender.")

    if r["wrong_defenses"]:
        print(f"  ❌ WRONG DEFENSES (defender played a different action than "
              f"Strat.txt prescribes) ({len(r['wrong_defenses'])}):")
        for x in r["wrong_defenses"]:
            print(f"     ts={x['ts']:.2f}  key={x['key']}  "
                  f"played={x['played']}  prescribed={x['prescribed']}")
    else:
        print(f"  ✓ Every defense played matches Strat.txt for the perceived state.")

    if r["no_strat_match"]:
        print(f"  ⚠️  NO STRAT MATCH (state tuple not in Strat.txt) "
              f"({len(r['no_strat_match'])}):")
        for x in r["no_strat_match"][:5]:
            print(f"     ts={x['ts']:.2f}  key={x['key']}")

    print()
    print(f"  HEALTHY = {r['healthy']}")
    print()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("trial_dir")
    ap.add_argument("--strat", default="/home/f1tenth/finalVersion/Strat.txt")
    args = ap.parse_args()

    r = audit(args.trial_dir, args.strat)
    print_report(r)
    sys.exit(0 if r["healthy"] else 1)


if __name__ == "__main__":
    main()
