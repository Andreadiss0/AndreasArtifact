#!/usr/bin/env python3
"""Per-run aggregator.

After all trials of one configuration have completed, read summary.csv
and verification.csv, and emit:
  - verdict breakdown (overall + healthy-only)
  - per-REQ trigger rate
  - per-action coverage
  - PRISM-bound comparison (for synth_vs_random vs analytical 0.1422)
  - raw-file pointers for every claim

Writes to <run_dir>/analysis.md.

Usage:
    python3 aggregate_run.py <run_dir>
"""
from __future__ import annotations
import sys, os, csv, collections

PRISM_ANALYTICAL_PMAX = 0.1422   # <<att>> Pmax=? [F sysC] on the with-give-up SMG
PRISM_ANALYTICAL_COST = 122      # <<att>> R{cost}min=? [F sysC] on no-give-up SMG


def read_verification(run_dir):
    csv_path = os.path.join(run_dir, "verification.csv")
    if not os.path.exists(csv_path):
        return []
    with open(csv_path) as f:
        return list(csv.DictReader(f))


def write_md(run_dir, lines):
    out_path = os.path.join(run_dir, "analysis.md")
    with open(out_path, "w") as f:
        f.write("\n".join(lines) + "\n")
    return out_path


def main():
    if len(sys.argv) < 2:
        sys.stderr.write("usage: aggregate_run.py <run_dir>\n")
        sys.exit(2)
    run_dir = sys.argv[1].rstrip("/")
    run_name = os.path.basename(run_dir)
    rows = read_verification(run_dir)
    if not rows:
        sys.stderr.write("no verification rows yet\n")
        sys.exit(2)

    n_total   = len(rows)
    healthy   = [r for r in rows if r["healthy"] == "1"]
    unhealthy = [r for r in rows if r["healthy"] != "1"]
    n_healthy = len(healthy)

    # Verdict breakdown overall + healthy
    def verdict_counts(group):
        c = collections.Counter(r["verdict"] for r in group)
        return c

    v_all = verdict_counts(rows)
    v_healthy = verdict_counts(healthy)

    def pmax(group):
        if not group:
            return None
        wins = sum(1 for r in group if r["verdict"] == "ATTACKER_WIN")
        return wins / len(group)

    pmax_all     = pmax(rows)
    pmax_healthy = pmax(healthy)

    # Per-REQ trigger rate
    req_counter = collections.Counter()
    for r in rows:
        for req in (r["alerts_seen"] or "").split("|"):
            if req:
                req_counter[req] += 1

    # Per-action SUCCESS coverage
    action_counter = collections.Counter()
    for r in rows:
        for act in (r["success_actions"] or "").split("|"):
            if act:
                action_counter[act] += 1

    # Unhealthy reasons summary
    unhealthy_reasons = collections.Counter()
    for r in unhealthy:
        for reason in (r["health_reasons"] or "").split("|"):
            if reason:
                # Drop the value, just keep the reason name
                key = reason.split("=")[0]
                unhealthy_reasons[key] += 1

    # Lists of which trials had which verdict (for spot-checks)
    win_trials      = [r["trial"] for r in rows if r["verdict"] == "ATTACKER_WIN"]
    healthy_wins    = [r["trial"] for r in healthy if r["verdict"] == "ATTACKER_WIN"]
    unhealthy_list  = [r["trial"] for r in unhealthy]

    lines = []
    lines.append(f"# Analysis: {run_name}")
    lines.append("")
    lines.append(f"_Source: `{run_dir}/summary.csv` and `{run_dir}/verification.csv`._")
    lines.append("")

    lines.append("## Trial population")
    lines.append("")
    lines.append(f"- Total trials in run: **{n_total}**")
    lines.append(f"- Healthy trials (passed every verification check): **{n_healthy}**")
    lines.append(f"- Unhealthy trials: **{n_total - n_healthy}**")
    if unhealthy:
        lines.append(f"  - Reasons:")
        for k, v in unhealthy_reasons.most_common():
            lines.append(f"    - `{k}`: {v} trial(s)")
        lines.append(f"  - Unhealthy trial numbers: {', '.join(unhealthy_list)}")
        lines.append(f"  - Inspect: `{run_dir}/trial_<N>/{{attacker,monitor,defender,alerts}}.log`")
    lines.append("")

    lines.append("## Verdict breakdown")
    lines.append("")
    lines.append("| Verdict | Overall | Healthy-only |")
    lines.append("|---|---|---|")
    for v in ("ATTACKER_WIN", "DEFENDER_WIN_GIVE_UP",
              "DEFENDER_WIN_COST_EXHAUSTED", "DEFENDER_WIN_TIMEOUT"):
        lines.append(f"| {v} | {v_all.get(v, 0)} | {v_healthy.get(v, 0)} |")
    lines.append("")
    lines.append(f"- Empirical Pmax overall: **{pmax_all:.3f}** ({sum(1 for r in rows if r['verdict']=='ATTACKER_WIN')}/{n_total})")
    if pmax_healthy is not None:
        lines.append(f"- Empirical Pmax (healthy-only): **{pmax_healthy:.3f}** ({len(healthy_wins)}/{n_healthy})")
    lines.append("")
    if win_trials:
        lines.append(f"- ATTACKER_WIN trials (verify by hand if you wish): {', '.join(win_trials)}")
        lines.append(f"  - Each trial's log: `{run_dir}/trial_<N>/attacker.log`")
    lines.append("")

    # PRISM comparison only for synth_vs_random
    if run_name == "synth_vs_random":
        lines.append("## Comparison to PRISM analytical bound")
        lines.append("")
        lines.append(f"- PRISM-games `<<att>> Pmax=? [F sysC]` on the deployed SMG returns **{PRISM_ANALYTICAL_PMAX}**.")
        ph_str = f"{pmax_healthy:.3f}" if pmax_healthy is not None else "n/a"
        lines.append(f"- Empirical Pmax (healthy-only): **{ph_str}**.")
        if pmax_healthy is not None:
            delta = pmax_healthy - PRISM_ANALYTICAL_PMAX
            sign = "above" if delta > 0 else "below"
            lines.append(f"- Empirical is **{abs(delta):.3f} {sign}** the analytical bound.")
        lines.append("")
        lines.append("Possible sources of the gap (in order of expected magnitude):")
        lines.append("1. Runtime attacker is uniform-random, not the cost-min attacker PRISM assumes.")
        lines.append("2. Monitor false negatives (timing race, cooldown TTL).")
        lines.append("3. Defender reliability variance over N=100 trials.")
        lines.append("4. State.json revoke vs live ROS subprocess teardown drift.")
        lines.append("5. Pre-PRISM foothold steps (initialAccess, lateralAccess) consume runtime cost not modelled by PRISM.")
        lines.append("")

    lines.append("## Per-REQ trigger rate")
    lines.append("")
    lines.append("| REQ | Trials triggered | Rate |")
    lines.append("|---|---|---|")
    for req, c in req_counter.most_common():
        lines.append(f"| `{req}` | {c} / {n_total} | {c/n_total:.2f} |")
    lines.append("")

    lines.append("## Attacker-action SUCCESS coverage")
    lines.append("")
    lines.append("| Action | Trials where SUCCESS at least once |")
    lines.append("|---|---|")
    for act, c in action_counter.most_common():
        lines.append(f"| `{act}` | {c} / {n_total} |")
    lines.append("")

    out_path = write_md(run_dir, lines)
    print(f"wrote {out_path}")


if __name__ == "__main__":
    main()
