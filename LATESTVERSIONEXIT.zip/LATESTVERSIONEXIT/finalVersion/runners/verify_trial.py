#!/usr/bin/env python3
"""Per-trial verifier.

Given a trial directory (e.g. experiment_runs/none_vs_random/trial_5/),
reads attacker.log, monitor.log, alerts.log and emits a JSON line on
stdout summarising what happened:

    {
      "trial": 5,
      "scan_pub_first":  1,
      "scan_pub_last":   1,
      "drive_pub_min":   1,
      "drive_rate_min":  20,
      "verdict":         "ATTACKER_WIN",
      "alerts_seen":     ["REQ_credential_access", ...],
      "success_actions": ["credentialAccess(robot_host)", ...],
      "missing_alerts":  [],
      "healthy":         true
    }

Also appends a one-line summary to <run_dir>/verification.csv.

Used by clean_run.sh after every trial. Never silently passes — if a
trial is unhealthy, healthy=false and the runner prints a loud warning.

Usage:
    python3 verify_trial.py <trial_dir>
"""
from __future__ import annotations
import sys, os, re, json, csv, glob

# Same mapping the audit used. Only actions that produce a monitor signal
# directly (capability predicates do not, they're observed via downstream
# effects).
EXPECTED_ALERT = {
    "credentialAccess(robot_host)":                        "REQ_credential_access",
    "maliciousTopicContent('/scan')":                      "REQ_scan_corrupted",
    "stalePublish('/scan')":                               "REQ_scan_corrupted",
    "mitmInjection('/scan')":                              "REQ_scan_corrupted",
    "topicDrop('/scan')":                                  "REQ_scan_unreliable",
    "topicDelay('/scan')":                                 "REQ_scan_unreliable",
    "qosDegradation('/scan')":                             "REQ_scan_unreliable",
    "reliabilityFlip('/scan')":                            "REQ_scan_unreliable",
    "topicFlood('/drive')":                                "REQ_drive_DoS",
    "gradualDrift('/drive')":                              "REQ_command_unsafe",
    "arrayDosExploit(bridge,'/drive')":                    "REQ_drive_DoS",
    "lifecycleHijack(map_server)":                         "REQ_map_server_down",
    "serviceCall('/map_server/change_state',map_server)":  "REQ_map_server_down",
    "serviceCall('/map_server/set_parameters',map_server)":"REQ_map_server_down",
    "serviceCall('/bridge/set_parameters',bridge)":        "REQ_bridge_misconfigured",
    "topicRead('/scan')":                                  "REQ_data_leaked",
    "topicRead('/odom')":                                  "REQ_data_leaked",
}

VERDICTS = (
    "ATTACKER_WIN",
    "DEFENDER_WIN_GIVE_UP",
    "DEFENDER_WIN_COST_EXHAUSTED",
    "DEFENDER_WIN_TIMEOUT",
)


def parse_monitor(monitor_path: str) -> dict:
    """Return discovery health metrics from a monitor.log.

    Only counts ticks AFTER the per-trial "alert latches + PTLTL state +
    inotify counter reset" marker so we ignore ticks emitted while DDS
    is still settling at monitor startup.
    """
    out = {
        "scan_pub_first": None,
        "scan_pub_last":  None,
        "drive_pub_min":  None,
        "drive_rate_min": None,
        "tick_count":     0,
        "scan_pub_zero_ticks": 0,
        "reset_seen":     False,
    }
    if not os.path.exists(monitor_path):
        return out

    tick_re = re.compile(
        r"drive\[pub=(\d+) rate=(\d+) speed=([\d.]+) steer=([\d.\-]+)\] "
        r"scan\[pub=(\d+) sub=(\d+) rate=(\d+)"
    )

    counting = False
    with open(monitor_path) as f:
        for line in f:
            if "alert latches + PTLTL state + inotify counter reset" in line:
                counting = True
                out["reset_seen"] = True
                continue
            if not counting:
                continue
            m = tick_re.search(line)
            if not m:
                continue
            dpub  = int(m.group(1))
            drate = int(m.group(2))
            spub  = int(m.group(5))
            out["tick_count"] += 1

            if out["scan_pub_first"] is None:
                out["scan_pub_first"] = spub
            out["scan_pub_last"] = spub
            if spub == 0:
                out["scan_pub_zero_ticks"] += 1

            if out["drive_pub_min"] is None or dpub < out["drive_pub_min"]:
                out["drive_pub_min"] = dpub
            if out["drive_rate_min"] is None or drate < out["drive_rate_min"]:
                out["drive_rate_min"] = drate

    return out


def parse_attacker(attacker_path: str) -> dict:
    """Return verdict + per-step SUCCESS actions from attacker.log."""
    out = {
        "verdict": "UNKNOWN",
        "success_actions": [],
        "steps": 0,
        "cumulative_cost_end": 0,
    }
    if not os.path.exists(attacker_path):
        return out

    chosen = None
    last_cost = 0
    with open(attacker_path) as f:
        for line in f:
            if "========== ATTACK STEP" in line:
                out["steps"] += 1
                continue

            m = re.search(r"Chosen attack action: (.+)$", line)
            if m:
                chosen = m.group(1).strip()
                continue

            if chosen and ("-> SUCCESS" in line or "deterministic SUCCESS" in line):
                out["success_actions"].append(chosen)
                chosen = None

            m = re.search(r"cumulative=(\d+)", line)
            if m:
                last_cost = int(m.group(1))

            if "Attacker reached systemCompromised" in line:
                out["verdict"] = "ATTACKER_WIN"
            elif "Attacker gave up" in line:
                out["verdict"] = "DEFENDER_WIN_GIVE_UP"
            elif "Attacker cost budget exhausted" in line:
                out["verdict"] = "DEFENDER_WIN_COST_EXHAUSTED"
            elif "MAX_STEPS=" in line and "reached without compromise" in line:
                out["verdict"] = "DEFENDER_WIN_TIMEOUT"

    out["cumulative_cost_end"] = last_cost
    return out


def parse_alerts(alerts_path: str) -> list:
    """Return list of REQ_* alert types seen in alerts.log."""
    seen = set()
    if not os.path.exists(alerts_path):
        return []
    with open(alerts_path) as f:
        for line in f:
            for tok in re.findall(r"REQ_[a-z_]+", line):
                seen.add(tok)
    return sorted(seen)


def verify(trial_dir: str) -> dict:
    """Run all checks on one trial directory. Return verification dict."""
    monitor_path  = os.path.join(trial_dir, "monitor.log")
    attacker_path = os.path.join(trial_dir, "attacker.log")
    alerts_path   = os.path.join(trial_dir, "alerts.log")

    m = parse_monitor(monitor_path)
    a = parse_attacker(attacker_path)
    alerts_seen = parse_alerts(alerts_path)

    # What alerts SHOULD have fired given the SUCCESS actions?
    expected = set()
    for act in a["success_actions"]:
        if act in EXPECTED_ALERT:
            expected.add(EXPECTED_ALERT[act])
    missing = sorted(expected - set(alerts_seen))

    # Healthy iff every box is checked
    healthy = True
    health_reasons = []

    # /scan publisher discovery is the bridge-corruption signal. If the
    # first tick sees pub>=1 but later ticks see pub=0 for a sustained
    # period, the bridge has been corrupted by stolen-creds traffic.
    if m["scan_pub_first"] is None or m["scan_pub_first"] < 1:
        healthy = False
        health_reasons.append(f"scan_pub_first={m['scan_pub_first']}")
    if m["scan_pub_last"] is None or m["scan_pub_last"] < 1:
        healthy = False
        health_reasons.append(f"scan_pub_last={m['scan_pub_last']}")
    # If more than half of the ticks reported scan_pub=0, the discovery
    # was broken for most of the trial.
    if m["tick_count"] > 0 and m["scan_pub_zero_ticks"] > m["tick_count"] / 2:
        healthy = False
        health_reasons.append(
            f"scan_pub_zero_majority={m['scan_pub_zero_ticks']}/{m['tick_count']}"
        )
    # drive_pub and drive_rate legitimately go to 0 during defender
    # brake actions, so don't gate on them.
    if a["verdict"] not in VERDICTS:
        healthy = False
        health_reasons.append(f"verdict={a['verdict']}")
    if missing:
        healthy = False
        health_reasons.append(f"missing_alerts={missing}")

    return {
        "trial":           os.path.basename(trial_dir).replace("trial_", ""),
        "verdict":         a["verdict"],
        "steps":           a["steps"],
        "cumulative_cost": a["cumulative_cost_end"],
        "scan_pub_first":  m["scan_pub_first"],
        "scan_pub_last":   m["scan_pub_last"],
        "scan_pub_zero_ticks": m["scan_pub_zero_ticks"],
        "drive_pub_min":   m["drive_pub_min"],
        "drive_rate_min":  m["drive_rate_min"],
        "tick_count":      m["tick_count"],
        "alerts_seen":     alerts_seen,
        "success_actions": a["success_actions"],
        "missing_alerts":  missing,
        "healthy":         healthy,
        "health_reasons":  health_reasons,
    }


def append_to_csv(run_dir: str, result: dict) -> None:
    """Append one trial's verification result to <run_dir>/verification.csv."""
    csv_path = os.path.join(run_dir, "verification.csv")
    fields = [
        "trial", "verdict", "steps", "cumulative_cost",
        "scan_pub_first", "scan_pub_last", "scan_pub_zero_ticks",
        "drive_pub_min", "drive_rate_min", "tick_count",
        "alerts_seen", "success_actions", "missing_alerts",
        "healthy", "health_reasons",
    ]
    write_header = not os.path.exists(csv_path)
    with open(csv_path, "a", newline="") as f:
        w = csv.writer(f)
        if write_header:
            w.writerow(fields)
        w.writerow([
            result["trial"], result["verdict"], result["steps"],
            result["cumulative_cost"], result["scan_pub_first"],
            result["scan_pub_last"], result["scan_pub_zero_ticks"],
            result["drive_pub_min"], result["drive_rate_min"],
            result["tick_count"],
            "|".join(result["alerts_seen"]),
            "|".join(result["success_actions"]),
            "|".join(result["missing_alerts"]),
            int(result["healthy"]),
            "|".join(result["health_reasons"]),
        ])


def main():
    if len(sys.argv) < 2:
        sys.stderr.write("usage: verify_trial.py <trial_dir>\n")
        sys.exit(2)
    trial_dir = sys.argv[1].rstrip("/")
    if not os.path.isdir(trial_dir):
        sys.stderr.write(f"not a directory: {trial_dir}\n")
        sys.exit(2)
    run_dir = os.path.dirname(trial_dir)
    result  = verify(trial_dir)
    append_to_csv(run_dir, result)
    print(json.dumps(result))


if __name__ == "__main__":
    main()
