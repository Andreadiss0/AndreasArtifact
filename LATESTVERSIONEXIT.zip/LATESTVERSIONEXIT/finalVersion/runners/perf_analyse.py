import sys, os, csv, statistics
from collections import defaultdict

OUT_ROOT = sys.argv[1] if len(sys.argv) > 1 else \
    "/home/f1tenth/finalVersion/experiment_runs/perf_overhead"
CLK_TCK = 100.0

conditions = ["baseline", "monitor_only", "monitor_defender", "full"]

def load_condition(cond):
    base = os.path.join(OUT_ROOT, cond)
    s_path = os.path.join(base, "samples.csv")
    t_path = os.path.join(base, "throughput.csv")
    if not (os.path.exists(s_path) and os.path.exists(t_path)):
        return None
    per_window_proc = defaultdict(lambda: defaultdict(list))
    with open(s_path) as f:
        for row in csv.DictReader(f):
            w = int(row["window"])
            t = int(row["t_sec"])
            proc = row["proc"]
            cu = int(row["cpu_user"])
            cs = int(row["cpu_sys"])
            rss = int(row["vm_rss_kb"])
            per_window_proc[w][proc].append((t, cu, cs, rss))
    throughput = []
    with open(t_path) as f:
        for row in csv.DictReader(f):
            throughput.append({
                "window": int(row["window"]),
                "topic": row["topic"],
                "hz": float(row["hz"]),
                "n_samples": int(row["n_samples"]),
            })
    return per_window_proc, throughput

def cpu_pct_per_window(per_window_proc):
    out = defaultdict(list)
    for w, procs in per_window_proc.items():
        for proc, rows in procs.items():
            rows = sorted(rows)
            if len(rows) < 2: continue
            (_, cu0, cs0, _) = rows[0]
            (tf, cuf, csf, _) = rows[-1]
            t0 = rows[0][0]
            elapsed = max(tf - t0, 1)
            ticks = (cuf + csf) - (cu0 + cs0)
            cpu_pct = 100.0 * (ticks / CLK_TCK) / elapsed
            out[proc].append(cpu_pct)
    return out

def rss_mean_per_window(per_window_proc):
    out = defaultdict(list)
    for w, procs in per_window_proc.items():
        for proc, rows in procs.items():
            if not rows: continue
            rss_vals = [r[3] for r in rows]
            out[proc].append(statistics.mean(rss_vals))
    return out

def mstd(vals):
    if not vals: return "—"
    if len(vals) == 1: return f"{vals[0]:.1f}"
    return f"{statistics.mean(vals):.1f} ± {statistics.stdev(vals):.1f}"

def topic_stat(throughput, topic):
    hz = [r["hz"] for r in throughput if r["topic"] == topic]
    if not hz: return "—"
    if len(hz) == 1: return f"{hz[0]:.1f}"
    return f"{statistics.mean(hz):.1f} ± {statistics.stdev(hz):.1f}"

rows = []
for cond in conditions:
    d = load_condition(cond)
    if d is None:
        rows.append({"condition": cond, "loaded": False})
        continue
    pwp, thr = d
    cpu = cpu_pct_per_window(pwp)
    rss = rss_mean_per_window(pwp)
    nw = len({w for w, _ in pwp.items()})
    rows.append({
        "condition": cond,
        "loaded": True,
        "n_windows": nw,
        "scan_hz": topic_stat(thr, "/scan"),
        "drive_hz": topic_stat(thr, "/drive"),
        "bridge_cpu": mstd(cpu.get("bridge", [])),
        "normal_cpu": mstd(cpu.get("normal", [])),
        "monitor_cpu": mstd(cpu.get("monitor", [])),
        "defender_cpu": mstd(cpu.get("defender", [])),
        "attacker_cpu": mstd(cpu.get("attacker", [])),
        "monitor_rss_mb": (f"{statistics.mean(rss.get('monitor', [0]))/1024:.1f}"
                           if rss.get("monitor") else "—"),
        "defender_rss_mb": (f"{statistics.mean(rss.get('defender', [0]))/1024:.1f}"
                            if rss.get("defender") else "—"),
    })

cols = ["condition", "n_windows", "scan_hz", "drive_hz",
        "bridge_cpu", "normal_cpu",
        "monitor_cpu", "defender_cpu", "attacker_cpu",
        "monitor_rss_mb", "defender_rss_mb"]
widths = [max(len(c), max((len(str(r.get(c, "—"))) for r in rows if r.get("loaded")), default=3))
          for c in cols]

def line(vals):
    return "  ".join(str(v).ljust(w) for v, w in zip(vals, widths))

print(line(cols))
print(line(["-" * w for w in widths]))
for r in rows:
    if not r.get("loaded"):
        print(f"{r['condition']}  (no data)")
        continue
    print(line([r.get(c, "—") for c in cols]))
