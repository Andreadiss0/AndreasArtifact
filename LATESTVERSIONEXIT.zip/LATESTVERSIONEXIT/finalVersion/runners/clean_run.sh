#!/bin/bash
# Usage: clean_run.sh <run_name> <trials>

set -u

if [ "$#" -lt 2 ]; then
  echo "usage: $0 <run_name> <trials>" >&2
  exit 2
fi

RUN_NAME="$1"
TRIALS="$2"

case "$RUN_NAME" in
  none_vs_random)            DEF=none;   ATT=random     ;;
  random_vs_random)          DEF=random; ATT=random     ;;
  synth_vs_random)           DEF=synth;  ATT=random     ;;
  synth_vs_costaware)        DEF=synth;  ATT=cost_aware ;;
  synth_vs_smgstrat)         DEF=synth;  ATT=smg_strat  ;;
  synth_nogu_vs_costaware)   DEF=synth;  ATT=cost_aware
                             export DEFENDER_STRAT_FILE=/home/f1tenth/finalVersion/DefStratNoGiveUp.txt
                             export ATTACK_NO_GIVE_UP=1 ;;
  synth_nogu_vs_smgstrat)    DEF=synth;  ATT=smg_strat
                             export DEFENDER_STRAT_FILE=/home/f1tenth/finalVersion/DefStratNoGiveUp.txt
                             export ATTACK_NO_GIVE_UP=1 ;;
  *)
    echo "unknown run name: $RUN_NAME" >&2
    exit 2
    ;;
esac

export DEFENDER_POLICY="$DEF"
export ATTACKER_POLICY="$ATT"
export ATTACK_BUDGET_TOTAL="${ATTACK_BUDGET_TOTAL:-122}"

OUT_DIR=${OUT_DIR_OVERRIDE:-/home/f1tenth/finalVersion/experiment_runs/$RUN_NAME}
RUNNERS=/home/f1tenth/finalVersion/runners
WORK_DIR=/home/f1tenth/finalVersion/trials

# Archive any previous run dir (skip when resuming with START_TRIAL>1)
mkdir -p "$(dirname "$OUT_DIR")"
if [ -d "$OUT_DIR" ] && [ "${START_TRIAL:-1}" = "1" ]; then
  mv "$OUT_DIR" "${OUT_DIR}.bak_$(date +%Y%m%d_%H%M%S)"
fi
mkdir -p "$OUT_DIR"

echo "============================================================="
echo "  clean_run: $RUN_NAME"
echo "  trials:    $TRIALS"
echo "  budget:    $ATTACK_BUDGET_TOTAL"
echo "  defender:  $DEFENDER_POLICY  attacker: $ATTACKER_POLICY"
echo "  output:    $OUT_DIR"
echo "  started:   $(date)"
echo "============================================================="

kill_all_procs() {
  pkill -9 -f attacker_agent_test 2>/dev/null
  pkill -9 -f defender_agent 2>/dev/null
  pkill -9 -f system_monitor_node 2>/dev/null
  pkill -9 -f alerts_sniffer 2>/dev/null
  pkill -9 -f run_attacker.sh 2>/dev/null
  pkill -9 -f normal_driver 2>/dev/null
  pkill -9 -f gym_bridge 2>/dev/null
  pkill -9 -f map_server 2>/dev/null
  pkill -9 -f rviz2 2>/dev/null
  pkill -9 -f run_alerts.sh 2>/dev/null
  pkill -9 -f run_defender.sh 2>/dev/null
  pkill -9 -f run_monitor.sh 2>/dev/null
  pkill -9 -f "ros2 launch f1tenth_gym_ros" 2>/dev/null
  sudo -n tc qdisc del dev lo root 2>/dev/null
  sudo -n tc qdisc del dev eth0 root 2>/dev/null
  sudo -n tc qdisc del dev wlan0 root 2>/dev/null
  rm -rf /dev/shm/* 2>/dev/null
  ros2 daemon stop 2>/dev/null || true
  sleep 1
}

wait_for_proc() {
  local pat="$1"
  local secs="${2:-10}"
  local deadline=$((SECONDS + secs))
  while [ "$SECONDS" -lt "$deadline" ]; do
    if pgrep -f "$pat" > /dev/null 2>&1; then
      return 0
    fi
    sleep 0.5
  done
  return 1
}

restart_sim_and_driver() {
  kill_all_procs

  # Start sim
  DISPLAY=:0 nohup /home/f1tenth/run_sim.sh > /tmp/run_sim.log 2>&1 &
  if ! wait_for_proc "gym_bridge" 20; then
    echo "[trial $1] FATAL: sim did not come up within 20 s" >&2
    return 1
  fi
  # Let DDS settle and rviz boot
  sleep 12

  # Start normal_driver
  nohup /home/f1tenth/run_normal_op.sh > /tmp/normal_op.log 2>&1 &
  if ! wait_for_proc "python3 /home/f1tenth/normal_driver.py" 10; then
    echo "[trial $1] FATAL: normal_driver did not come up within 10 s" >&2
    return 1
  fi
  sleep 4

  # Verify both are alive
  if ! pgrep -f gym_bridge > /dev/null; then
    echo "[trial $1] FATAL: sim died after startup" >&2
    return 1
  fi
  if ! pgrep -f "python3 /home/f1tenth/normal_driver.py" > /dev/null; then
    echo "[trial $1] FATAL: normal_driver died after startup" >&2
    return 1
  fi
  return 0
}

run_single_trial() {
  local n=$1
  local d="$WORK_DIR/trial_$n"
  rm -rf "$d"
  mkdir -p "$d"

  echo ""
  echo "================================================================="
  echo "  TRIAL $n / $TRIALS  ($RUN_NAME)  @ $(date +%H:%M:%S)"
  echo "================================================================="

  # Restart sim + driver fresh
  if ! restart_sim_and_driver "$n"; then
    echo "[trial $n] sim/driver restart failed — skipping" >&2
    return 1
  fi

  # Per-trial state cleanup
  rm -f /home/f1tenth/finalVersion/state.json
  rm -f /tmp/turn_complete.flag
  rm -f /tmp/defender_last_turn.json
  rm -f /tmp/attacker_step_done.flag
  rm -f /tmp/stolen_ros_creds /tmp/attacker_netadmin.log /tmp/bridge_recon.log
  rm -rf /tmp/stolen_ros_keystore 2>/dev/null
  rm -f /tmp/runtime_combined.log /tmp/runtime_combined.start_ts

  echo "[trial $n] starting monitor (6 s warm-up for DDS discovery)..."
  ~/run_monitor.sh > "$d/monitor.log" 2>&1 &
  echo $! > "$d/monitor.pid"
  sleep 6

  ~/reset_car.sh > /dev/null 2>&1
  sleep 0.5
  pkill -USR1 -f "system_monitor_v2/lib/system_monitor_v2/system_monitor_node" 2>/dev/null || true
  sleep 0.2

  echo "[trial $n] starting alerts sniffer..."
  ~/run_alerts.sh > "$d/alerts.log" 2>&1 &
  echo $! > "$d/sniffer.pid"
  sleep 0.3

  if [ "$DEF" != "none" ]; then
    echo "[trial $n] starting defender ($DEF)..."
    ~/run_defender.sh > "$d/defender.log" 2>&1 &
    echo $! > "$d/defender.pid"
    sleep 0.3
  else
    echo "[trial $n] defender=none, skipping defender process"
    : > "$d/defender.log"
  fi

  echo "[trial $n] running attacker ($ATT) at budget $ATTACK_BUDGET_TOTAL..."
  ~/run_attacker.sh > "$d/attacker.log" 2>&1
  ATT_RC=$?
  sleep 0.3

  cp /tmp/runtime_combined.log "$d/combined.log" 2>/dev/null || true

  if grep -q "Attacker reached systemCompromised" "$d/attacker.log"; then
    verdict="ATTACKER_WIN"
  elif grep -q "Attacker gave up" "$d/attacker.log"; then
    verdict="DEFENDER_WIN_GIVE_UP"
  elif grep -q "Attacker cost budget exhausted" "$d/attacker.log"; then
    verdict="DEFENDER_WIN_COST_EXHAUSTED"
  elif grep -q "MAX_STEPS=.* reached without compromise" "$d/attacker.log"; then
    verdict="DEFENDER_WIN_TIMEOUT"
  else
    verdict="UNKNOWN"
  fi

  steps=$(grep -c '========== ATTACK STEP' "$d/attacker.log" 2>/dev/null)
  alerts=$(grep -cE '^\[1[0-9]+\.' "$d/alerts.log" 2>/dev/null)
  defenses=$(grep -c 'strategy says:' "$d/defender.log" 2>/dev/null)
  cost=$(grep -oP 'cumulative=\K[0-9]+' "$d/attacker.log" 2>/dev/null | tail -1)
  [ -z "$steps" ]    && steps=0
  [ -z "$alerts" ]   && alerts=0
  [ -z "$defenses" ] && defenses=0
  [ -z "$cost" ]     && cost=0
  alert_list=$(grep -oE 'REQ_[a-z_]+' "$d/alerts.log" 2>/dev/null | sort -u | tr '\n' '|' | sed 's/|$//')
  defense_list=$(grep -oE 'def_[a-z_]+' "$d/defender.log" 2>/dev/null | sort -u | tr '\n' '|' | sed 's/|$//')

  echo "[trial $n] DONE   verdict=$verdict  steps=$steps  alerts=$alerts  defenses=$defenses  cost=$cost/$ATTACK_BUDGET_TOTAL"

  # Archive to per-run dir
  final_dir="$OUT_DIR/trial_$n"
  rm -rf "$final_dir"
  mv "$d" "$final_dir"

  # Append to per-run summary.csv
  if [ ! -f "$OUT_DIR/summary.csv" ]; then
    echo "trial,verdict,steps,alerts,defenses,cost,alert_list,defense_list" > "$OUT_DIR/summary.csv"
  fi
  echo "$n,$verdict,$steps,$alerts,$defenses,$cost,\"$alert_list\",\"$defense_list\"" >> "$OUT_DIR/summary.csv"

  # Run the per-trial verifier
  python3 "$RUNNERS/verify_trial.py" "$final_dir" > "$final_dir/verification.json" 2>&1 || true

  # Kill per-trial procs (sim will be killed at the next trial's restart)
  pkill -9 -f "system_monitor_v2/lib/system_monitor_v2/system_monitor_node" 2>/dev/null
  pkill -9 -f "defender_agent.py" 2>/dev/null
  pkill -9 -f "Node..alerts_sniffer" 2>/dev/null
  pkill -9 -f "ros2 run system_monitor_v2" 2>/dev/null

  # Every 10 trials, run the rolling healthcheck
  if [ $((n % 10)) -eq 0 ]; then
    echo ""
    echo "--- rolling healthcheck after trial $n ---"
    python3 "$RUNNERS/healthcheck_window.py" "$OUT_DIR" 10 || true
    echo "--- end healthcheck ---"
    echo ""
  fi
  return 0
}

# Main loop
rm -rf "$WORK_DIR"
mkdir -p "$WORK_DIR"

START_TRIAL="${START_TRIAL:-1}"
for i in $(seq "$START_TRIAL" "$TRIALS"); do
  run_single_trial "$i" || {
    echo "[trial $i] failed catastrophically — aborting run" >&2
    break
  }
done

# Final cleanup of sim
kill_all_procs

echo ""
echo "============================================================="
echo "  $RUN_NAME COMPLETE @ $(date)"
echo "============================================================="
echo "Final summary in $OUT_DIR/summary.csv"
echo "Per-trial verification in $OUT_DIR/verification.csv"
