#!/usr/bin/env python3
"""Final aggregate report across all five clean-run configurations.

Reads each run's verification.csv from
  experiment_runs/{none_vs_random, random_vs_random, synth_vs_random,
                   synth_vs_costaware, synth_vs_smgstrat}

and produces a single Markdown report covering:
  - Per-run verdict tables (Exp 1: three defenders × random; Exp 2: synth × three attackers)
  - Empirical-vs-analytical Pmax comparison
  - PRISM-gap discussion in §6 style

Writes to experiment_runs/final_report.md.

Usage:
    python3 final_report.py
"""
from __future__ import annotations
import os, csv, collections

PRISM_PMAX = 0.1422
PRISM_COST = 122

RUNS = [
    "none_vs_random",
    "random_vs_random",
    "synth_vs_random",
    "synth_vs_costaware",
    "synth_vs_smgstrat",
]

BASE = "/home/f1tenth/finalVersion/experiment_runs"


def read_run(run):
    csv_path = os.path.join(BASE, run, "verification.csv")
    if not os.path.exists(csv_path):
        return None
    with open(csv_path) as f:
        return list(csv.DictReader(f))


def verdict_counts(rows):
    return collections.Counter(r["verdict"] for r in rows)


def pmax(rows):
    if not rows:
        return None
    return sum(1 for r in rows if r["verdict"] == "ATTACKER_WIN") / len(rows)


def fmt_pmax(p):
    return f"{p:.3f}" if p is not None else "n/a"


def main():
    lines = []
    lines.append("# Final report: clean-run trial outcomes")
    lines.append("")
    lines.append(f"_Source: per-run `verification.csv` files under `{BASE}/`._")
    lines.append("")
    lines.append("This report is produced after running every trial through `clean_run.sh`, ")
    lines.append("which kills the sim and `normal_driver` and restarts them before every trial. ")
    lines.append("Per-trial `verify_trial.py` was used to flag trials whose monitor was not healthy. ")
    lines.append("Numbers below are reported both for the full 100-trial population and for ")
    lines.append("healthy-only trials.")
    lines.append("")

    # Per-run summary
    run_data = {}
    for run in RUNS:
        rows = read_run(run)
        if rows is None:
            run_data[run] = None
            continue
        n = len(rows)
        healthy = [r for r in rows if r["healthy"] == "1"]
        v_all = verdict_counts(rows)
        v_h = verdict_counts(healthy)
        run_data[run] = dict(
            n=n,
            n_healthy=len(healthy),
            pmax_all=pmax(rows),
            pmax_healthy=pmax(healthy),
            v_all=v_all,
            v_h=v_h,
        )

    # Experiment 1: three defenders vs random attacker
    lines.append("## Experiment 1: defender policy comparison")
    lines.append("")
    lines.append("Attacker: uniform-random selection from currently-enabled actions.")
    lines.append("")
    lines.append("| Defender | N | N healthy | Pmax overall | Pmax (healthy-only) |")
    lines.append("|---|---|---|---|---|")
    for run, label in [("none_vs_random", "None"),
                       ("random_vs_random", "Random"),
                       ("synth_vs_random", "Synthesized")]:
        d = run_data.get(run)
        if d is None:
            lines.append(f"| {label} | _no data_ | _no data_ | _no data_ | _no data_ |")
        else:
            lines.append(
                f"| {label} | {d['n']} | {d['n_healthy']} | "
                f"{fmt_pmax(d['pmax_all'])} | {fmt_pmax(d['pmax_healthy'])} |"
            )
    lines.append("")
    lines.append("Detailed verdict breakdown:")
    lines.append("")
    lines.append("| Defender | Compromise | Cost-exhausted | Gave up | Timeout |")
    lines.append("|---|---|---|---|---|")
    for run, label in [("none_vs_random", "None"),
                       ("random_vs_random", "Random"),
                       ("synth_vs_random", "Synthesized")]:
        d = run_data.get(run)
        if d is None:
            lines.append(f"| {label} | _no data_ | _no data_ | _no data_ | _no data_ |")
            continue
        v = d["v_all"]
        lines.append(
            f"| {label} | {v.get('ATTACKER_WIN',0)} | "
            f"{v.get('DEFENDER_WIN_COST_EXHAUSTED',0)} | "
            f"{v.get('DEFENDER_WIN_GIVE_UP',0)} | "
            f"{v.get('DEFENDER_WIN_TIMEOUT',0)} |"
        )
    lines.append("")

    # Experiment 2: synth defender vs three attackers
    lines.append("## Experiment 2: attacker policy comparison")
    lines.append("")
    lines.append("Defender: PRISM-synthesised strategy. Three attacker policies:")
    lines.append("- Random: uniform draw from enabled actions.")
    lines.append("- Cost-aware: sort enabled actions by per-action cost ascending, pick cheapest.")
    lines.append("- Cost-min (SMG strat): PRISM-synthesised cost-minimising attacker from the no-give-up SMG.")
    lines.append("")
    lines.append("| Attacker | N | N healthy | Pmax overall | Pmax (healthy-only) |")
    lines.append("|---|---|---|---|---|")
    for run, label in [("synth_vs_random", "Random"),
                       ("synth_vs_costaware", "Cost-aware"),
                       ("synth_vs_smgstrat", "Cost-min (SMG)")]:
        d = run_data.get(run)
        if d is None:
            lines.append(f"| {label} | _no data_ | _no data_ | _no data_ | _no data_ |")
        else:
            lines.append(
                f"| {label} | {d['n']} | {d['n_healthy']} | "
                f"{fmt_pmax(d['pmax_all'])} | {fmt_pmax(d['pmax_healthy'])} |"
            )
    lines.append("")

    # PRISM comparison
    lines.append("## Comparison to PRISM analytical bounds")
    lines.append("")
    lines.append(f"- `<<att>> Pmax=? [F sysC]` on the deployed SMG: **{PRISM_PMAX}** (vs synth defender, cost-min attacker).")
    lines.append(f"- `<<att>> R{{cost}}min=? [F sysC]` on the no-give-up SMG: **{PRISM_COST}** units expected attacker cost.")
    lines.append("")
    d = run_data.get("synth_vs_random")
    if d and d["pmax_healthy"] is not None:
        delta = d["pmax_healthy"] - PRISM_PMAX
        sign = "above" if delta > 0 else "below"
        lines.append(
            f"Empirical `synth_vs_random` Pmax (healthy-only): **{d['pmax_healthy']:.3f}** — "
            f"**{abs(delta):.3f} {sign}** the analytical bound."
        )
    lines.append("")
    lines.append("### Why the empirical Pmax may differ from PRISM")
    lines.append("")
    lines.append("Sources of the gap, in expected order of magnitude:")
    lines.append("")
    lines.append("1. **Runtime attacker is uniform-random.** PRISM assumes the cost-min attacker. ")
    lines.append("   Random plays sub-optimally, so the empirical Pmax should be lower than (or ")
    lines.append("   close to) the analytical bound.")
    lines.append("2. **Monitor false negatives.** Cooldown TTL, alert-publish timing races, ")
    lines.append("   inotify burst window misses. Each missed alert delays defender reaction.")
    lines.append("3. **Defender reliability variance.** PRISM uses fixed `q_d`. Over N=100 trials ")
    lines.append("   there is binomial spread of a few percentage points.")
    lines.append("4. **State.json revoke vs live ROS drift.** Defender flips a predicate to false ")
    lines.append("   in state.json instantly, but the live ROS subprocess or `tc` rule it represents ")
    lines.append("   takes longer to actually die. The SMG model assumes instantaneous revoke.")
    lines.append("5. **Pre-PRISM foothold steps.** `initialAccess` and `lateralAccess` consume ")
    lines.append("   runtime cost (5 and 2 units respectively) but are not in the SMG. So the ")
    lines.append("   effective budget the runtime attacker has against PRISM-modelled actions is ")
    lines.append(f"   smaller than the {PRISM_COST}-unit analytical baseline.")
    lines.append("")

    # Unhealthy trial summary
    lines.append("## Verification audit")
    lines.append("")
    lines.append("| Run | Healthy | Unhealthy | Healthy ratio |")
    lines.append("|---|---|---|---|")
    for run in RUNS:
        d = run_data.get(run)
        if d is None:
            lines.append(f"| {run} | _no data_ | _no data_ | _no data_ |")
            continue
        unhealthy = d["n"] - d["n_healthy"]
        ratio = d["n_healthy"] / d["n"] if d["n"] else 0
        lines.append(f"| {run} | {d['n_healthy']} | {unhealthy} | {ratio:.2f} |")
    lines.append("")
    lines.append("Per-run details and raw-file pointers are in `analysis.md` inside each run directory.")
    lines.append("")
    lines.append("All raw trial logs are preserved under ")
    lines.append("`experiment_runs/<run>/trial_<N>/{attacker,monitor,defender,alerts,combined}.log`. ")
    lines.append("Every percentage in this report can be independently verified from those files. ")
    lines.append("Nothing was deleted or filtered.")

    out_path = os.path.join(BASE, "final_report.md")
    os.makedirs(BASE, exist_ok=True)
    with open(out_path, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"wrote {out_path}")


if __name__ == "__main__":
    main()
