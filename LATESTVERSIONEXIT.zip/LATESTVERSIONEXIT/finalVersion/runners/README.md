# Pre-baked trial launchers

Each script sets `DEFENDER_POLICY` and `ATTACKER_POLICY`, then runs the
trial harness for N trials (defaults to 100, override as first arg) and
moves the output to a named subdirectory under
`/home/f1tenth/finalVersion/experiment_runs/` so successive runs do
not overwrite each other.

## How to run

You need THREE terminals open. Terminals 1 and 2 are persistent
processes; terminal 3 is where you launch trial batches.

### Terminal 1 — simulator

```
~/run_sim.sh
```

Leave it running for the whole session.

### Terminal 2 — background driver (wall-follower)

```
~/run_normal_op.sh
```

Leave it running for the whole session. This generates the realistic
laser / drive / odom traffic the monitor expects when no attack is
occurring.

### Terminal 3 — pick a launcher

Run one of these. Each runs 100 trials by default and saves the output
to `experiment_runs/{NAME}/`. Pass an integer as the first arg to use a
different trial count (e.g. `./synth_vs_costaware.sh 10` for a quick
dry-run).

| Launcher | Defender | Attacker | Use |
|---|---|---|---|
| `none_vs_random.sh`     | none   | random    | Exp 1 None baseline (already done) |
| `random_vs_random.sh`   | random | random    | Exp 1 Random baseline (already done) |
| `synth_vs_random.sh`    | synth  | random    | Exp 1 Synth main result (already done) |
| `none_vs_costaware.sh`  | none   | cost_aware | Exp 2 None anchor |
| `random_vs_costaware.sh`| random | cost_aware | Exp 2 Random (optional) |
| `synth_vs_costaware.sh` | synth  | cost_aware | Exp 2 main result |

Run them one at a time in terminal 3. Each batch of 100 trials takes
~2–4 hours on this VM.
