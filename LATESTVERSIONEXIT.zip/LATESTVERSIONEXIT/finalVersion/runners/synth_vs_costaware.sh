#!/bin/bash
# Defender: synthesized (PRISM-games strategy)
# Attacker: cost_aware (myopic min-cost)
#
# Experiment 2 — the headline test: does the synthesized strategy hold
# up against a cost-rational attacker?

set -u

# Trial count — pass an integer as the first arg, or default to 100.
TRIALS=${1:-100}
OUT_DIR=/home/f1tenth/finalVersion/experiment_runs/synth_vs_costaware

# Policy selection (the only things this launcher actually configures).
export DEFENDER_POLICY=synth
export ATTACKER_POLICY=cost_aware

echo "============================================================="
echo " synth_vs_costaware : ${TRIALS} trials -> ${OUT_DIR}"
echo "============================================================="

# Sanity checks. The simulator and normal_driver are persistent
# processes you start once, by hand, in their own terminals.
if ! pgrep -f "gym_bridge" > /dev/null; then
  echo "ERROR: simulator not running. Start ~/run_sim.sh in terminal 1." >&2
  exit 1
fi
if ! pgrep -f "normal_driver" > /dev/null; then
  echo "WARNING: normal_driver not running. Results will not match Exp 1." >&2
fi

# Archive an existing output dir so we never silently overwrite.
mkdir -p "$(dirname "$OUT_DIR")"
if [ -d "$OUT_DIR" ]; then
  mv "$OUT_DIR" "${OUT_DIR}.bak_$(date +%Y%m%d_%H%M%S)"
fi

# Run the harness. It spawns monitor + alerts sniffer + defender per
# trial and writes per-trial logs into ~/finalVersion/trials/trial_N/.
~/run_trials.sh "${TRIALS}"
status=$?

# Relocate the harness output to a named directory so the next
# launcher run does not clobber it.
if [ -d /home/f1tenth/finalVersion/trials ]; then
  mv /home/f1tenth/finalVersion/trials "$OUT_DIR"
  echo "Trial results: $OUT_DIR"
fi

exit "$status"
