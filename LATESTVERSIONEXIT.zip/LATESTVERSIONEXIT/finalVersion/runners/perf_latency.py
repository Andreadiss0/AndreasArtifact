import os, re, sys, glob, statistics

ROOT = sys.argv[1] if len(sys.argv) > 1 else \
    "/home/f1tenth/finalVersion/experiment_runs/perf_overhead/full"

# Match the rclpy info timestamp line:  [INFO] [1781126500.829007711] [defender_agent]: ...
TS = re.compile(r"\[INFO\] \[(\d+\.\d+)\] \[defender_agent\]:\s*(.*)$")

START_MARK = "turn drain:"
END_MARK   = "sent attacker back: revoked"

# Also record the raw alert-receive latency (alert -> revoke complete), which
# includes the step_done wait. Useful as upper bound.
ALERT_MARK = "added to pending set"

def parse_log(path):
    bracket_lats = []   # turn_drain -> sent_attacker_back
    alert_lats   = []   # alert_in -> sent_attacker_back
    pending_alert = None
    pending_drain = None
    with open(path, errors="replace") as f:
        for line in f:
            m = TS.search(line)
            if not m: continue
            ts = float(m.group(1)); body = m.group(2)
            if ALERT_MARK in body and pending_alert is None:
                pending_alert = ts
            elif START_MARK in body:
                pending_drain = ts
            elif END_MARK in body:
                if pending_drain is not None:
                    bracket_lats.append(ts - pending_drain)
                    pending_drain = None
                if pending_alert is not None:
                    alert_lats.append(ts - pending_alert)
                    pending_alert = None
    return bracket_lats, alert_lats

bracket_all = []
alert_all   = []
n_logs = 0
log_glob = os.path.join(ROOT, "defender_w*.log")
matches = sorted(glob.glob(log_glob))
if not matches:
    log_glob = os.path.join(ROOT, "defender.log")
    matches = sorted(glob.glob(log_glob))
for path in matches:
    n_logs += 1
    b, a = parse_log(path)
    bracket_all.extend(b); alert_all.extend(a)

def summarize(xs, name):
    if not xs:
        return f"{name}: no events"
    xs = sorted(xs)
    n = len(xs)
    med = statistics.median(xs)
    p95 = xs[max(0, int(0.95 * n) - 1)]
    mx  = xs[-1]
    mn  = xs[0]
    return f"{name}: n={n}  min={mn*1000:.0f}ms  median={med*1000:.0f}ms  p95={p95*1000:.0f}ms  max={mx*1000:.0f}ms"

print(f"defender logs scanned: {n_logs}")
print(summarize(bracket_all, "intrinsic (turn-drain -> sent-attacker-back)"))
print(summarize(alert_all,   "end-to-end (alert-receive -> sent-attacker-back, incl. step_done wait)"))
