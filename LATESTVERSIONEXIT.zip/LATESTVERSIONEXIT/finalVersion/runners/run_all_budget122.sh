#!/bin/bash
# Master runner: rerun Experiment 1 (3 defenders × random attacker) and
# Experiment 2 (3 attackers × synth defender) at the principled budget
# of 122 units (the PRISM-computed expected cost of the cost-minimizing
# attacker on the deployed SMG).
#
# Run sequentially. Five distinct runs because synth_vs_random is shared
# between Exp 1 and Exp 2. The cost-aware and smg_strat runs come last
# because they were the ones with stale data.

set -u

export ATTACK_BUDGET_TOTAL=122
TRIALS=${1:-100}

echo "============================================================="
echo "  Master rerun at ATTACK_BUDGET_TOTAL=${ATTACK_BUDGET_TOTAL}"
echo "  Trials per run: ${TRIALS}"
echo "  Started: $(date)"
echo "============================================================="

RUNS=(
  none_vs_random.sh
  random_vs_random.sh
  synth_vs_random.sh
  synth_vs_costaware.sh
  synth_vs_smgstrat.sh
)

for r in "${RUNS[@]}"; do
  echo ""
  echo "============================================================="
  echo "  Starting: ${r}  @ $(date)"
  echo "============================================================="
  /home/f1tenth/finalVersion/runners/${r} ${TRIALS}
  rc=$?
  if [ "$rc" -ne 0 ]; then
    echo "FAILED: ${r} exited ${rc}. Stopping." >&2
    exit "$rc"
  fi
done

echo ""
echo "============================================================="
echo "  ALL RUNS COMPLETE @ $(date)"
echo "============================================================="
