#!/bin/bash
# run_all_clean.sh — execute all five trial configurations sequentially,
# each through clean_run.sh (per-trial sim restart, per-trial verification).
#
# Default 100 trials per run. Override with first arg.
# Default budget 122. Override with ATTACK_BUDGET_TOTAL env var.
#
# Usage:
#   ./run_all_clean.sh        # 100 trials per run
#   ./run_all_clean.sh 10     # 10 trials per run (smoke test)

set -u

TRIALS="${1:-100}"
export ATTACK_BUDGET_TOTAL="${ATTACK_BUDGET_TOTAL:-122}"

RUNNERS=/home/f1tenth/finalVersion/runners
RUNS=(
  none_vs_random
  random_vs_random
  synth_vs_random
  synth_vs_costaware
  synth_vs_smgstrat
)

echo "============================================================="
echo "  run_all_clean: $TRIALS trials per run, budget $ATTACK_BUDGET_TOTAL"
echo "  started: $(date)"
echo "============================================================="

for run in "${RUNS[@]}"; do
  echo ""
  echo "============================================================="
  echo "  Starting: $run  @ $(date)"
  echo "============================================================="
  "$RUNNERS/clean_run.sh" "$run" "$TRIALS"
  rc=$?
  if [ "$rc" -ne 0 ]; then
    echo "WARN: $run exited with rc=$rc — continuing to next run anyway"
  fi
  # Always run the aggregator after each run, even on partial completion
  python3 "$RUNNERS/aggregate_run.py" "/home/f1tenth/finalVersion/experiment_runs/$run" || true
done

echo ""
echo "============================================================="
echo "  Generating final report"
echo "============================================================="
python3 "$RUNNERS/final_report.py"

echo ""
echo "============================================================="
echo "  ALL RUNS COMPLETE @ $(date)"
echo "============================================================="
echo "Per-run analysis: experiment_runs/<run>/analysis.md"
echo "Final report:     experiment_runs/final_report.md"
