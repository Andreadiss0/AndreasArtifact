#!/bin/bash
# perf_overhead.sh <condition> <n_windows>
# Runs n_windows independent 60s tests in one of four configurations,
# samples per-process CPU and RSS from /proc once per second, and
# counts /scan and /drive messages via _perf_hz_counter.py.

if [ "$#" -lt 2 ]; then
  echo "usage: $0 <condition> <n_windows>" >&2
  echo "  condition: baseline | monitor_only | monitor_defender | full" >&2
  exit 2
fi

CONDITION="$1"
N_WINDOWS="$2"
WINDOW_SEC="${WINDOW_SEC:-60}"
OUT_DIR="${OUT_DIR:-/home/f1tenth/finalVersion/experiment_runs/perf_overhead}"

case "$CONDITION" in
  baseline|monitor_only|monitor_defender|full) ;;
  *) echo "unknown condition: $CONDITION" >&2; exit 2 ;;
esac

mkdir -p "$OUT_DIR/$CONDITION"
SAMPLES_CSV="$OUT_DIR/$CONDITION/samples.csv"
THROUGHPUT_CSV="$OUT_DIR/$CONDITION/throughput.csv"

# Headers if files don't exist yet
if [ ! -f "$SAMPLES_CSV" ]; then
  echo "window,t_sec,proc,pid,cpu_user,cpu_sys,vm_rss_kb" > "$SAMPLES_CSV"
fi
if [ ! -f "$THROUGHPUT_CSV" ]; then
  echo "window,topic,hz,n_samples" > "$THROUGHPUT_CSV"
fi

kill_all_procs() {
  pkill -9 -f attacker_agent_test 2>/dev/null
  pkill -9 -f defender_agent 2>/dev/null
  pkill -9 -f system_monitor_node 2>/dev/null
  pkill -9 -f alerts_sniffer 2>/dev/null
  pkill -9 -f run_attacker.sh 2>/dev/null
  pkill -9 -f normal_driver 2>/dev/null
  pkill -9 -f gym_bridge 2>/dev/null
  pkill -9 -f map_server 2>/dev/null
  pkill -9 -f rviz2 2>/dev/null
  pkill -9 -f run_alerts.sh 2>/dev/null
  pkill -9 -f run_defender.sh 2>/dev/null
  pkill -9 -f run_monitor.sh 2>/dev/null
  pkill -9 -f "ros2 launch f1tenth_gym_ros" 2>/dev/null
  sudo -n tc qdisc del dev lo root 2>/dev/null
  rm -rf /dev/shm/* 2>/dev/null
  ros2 daemon stop 2>/dev/null || true
  sleep 2
}

wait_for_proc() {
  local pat="$1"
  local secs="${2:-15}"
  local deadline=$((SECONDS + secs))
  while [ "$SECONDS" -lt "$deadline" ]; do
    if pgrep -f "$pat" > /dev/null 2>&1; then return 0; fi
    sleep 0.5
  done
  return 1
}

start_sim_and_driver() {
  DISPLAY=:0 nohup /home/f1tenth/run_sim.sh > /tmp/perf_sim.log 2>&1 &
  if ! wait_for_proc "gym_bridge" 20; then
    echo "FATAL: sim did not come up" >&2; return 1
  fi
  sleep 12
  nohup /home/f1tenth/run_normal_op.sh > /tmp/perf_normal.log 2>&1 &
  if ! wait_for_proc "python3 /home/f1tenth/normal_driver.py" 10; then
    echo "FATAL: normal_driver did not come up" >&2; return 1
  fi
  sleep 4
}

start_monitor() {
  local w="${1:-0}"
  ~/run_monitor.sh > "$OUT_DIR/$CONDITION/monitor_w${w}.log" 2>&1 &
  sleep 6
}

start_defender() {
  local w="${1:-0}"
  ~/run_defender.sh > "$OUT_DIR/$CONDITION/defender_w${w}.log" 2>&1 &
  sleep 2
}

start_attacker() {
  local w="${1:-0}"
  ~/run_attacker.sh > "$OUT_DIR/$CONDITION/attacker_w${w}.log" 2>&1 &
  sleep 1
}

read_proc_stat() {
  local pid="$1"
  if [ ! -d "/proc/$pid" ]; then echo "0 0 0"; return; fi
  local s
  s=$(cat /proc/$pid/stat 2>/dev/null) || { echo "0 0 0"; return; }
  local utime stime
  utime=$(echo "$s" | awk '{print $14}')
  stime=$(echo "$s" | awk '{print $15}')
  local rss_kb
  rss_kb=$(awk '/VmRSS/{print $2}' /proc/$pid/status 2>/dev/null)
  rss_kb="${rss_kb:-0}"
  echo "$utime $stime $rss_kb"
}

pid_for() {
  local pat="$1"
  pgrep -f "$pat" 2>/dev/null | head -1
}

sample_window() {
  local w=$1
  local bridge_pid normal_pid monitor_pid defender_pid attacker_pid

  bridge_pid=$(pid_for "gym_bridge.*sim.yaml")
  normal_pid=$(pid_for "python3 /home/f1tenth/normal_driver.py")
  monitor_pid=$(pid_for "system_monitor_v2/lib/system_monitor_v2/system_monitor_node")
  defender_pid=$(pid_for "python3 /home/f1tenth/finalVersion/defender_agent.py")
  attacker_pid=$(pid_for "python3 attacker_agent_test.py")

  echo "  window $w PIDs: bridge=$bridge_pid normal=$normal_pid monitor=$monitor_pid defender=$defender_pid attacker=$attacker_pid"

  source /opt/ros/foxy/setup.bash 2>/dev/null || true
  source ~/sim_ws/install/setup.bash 2>/dev/null || true
  export ROS_DOMAIN_ID=0
  export ROS_LOCALHOST_ONLY=0
  export ROS_SECURITY_ENABLE=true
  export ROS_SECURITY_STRATEGY=Enforce
  export ROS_SECURITY_KEYSTORE=/home/f1tenth/sros2_keystore_f1tenth
  export ROS_SECURITY_ENCLAVE_OVERRIDE=/bridge
  export FASTRTPS_DEFAULT_PROFILES_FILE=/home/f1tenth/udp_only.xml

  local hz_json="/tmp/perf_hz_${CONDITION}_$w.json"
  local hz_log="/tmp/perf_hz_${CONDITION}_$w.log"
  python3 /home/f1tenth/finalVersion/runners/_perf_hz_counter.py \
      "$WINDOW_SEC" "$hz_json" > "$hz_log" 2>&1 &
  local hz_p=$!

  local t=0
  while [ $t -lt "$WINDOW_SEC" ]; do
    for entry in "bridge:$bridge_pid" "normal:$normal_pid" \
                 "monitor:$monitor_pid" "defender:$defender_pid" \
                 "attacker:$attacker_pid"; do
      local name="${entry%%:*}"
      local pid="${entry##*:}"
      if [ -n "$pid" ]; then
        read u s rss < <(read_proc_stat "$pid")
        echo "$w,$t,$name,$pid,$u,$s,$rss" >> "$SAMPLES_CSV"
      fi
    done
    sleep 1
    t=$((t + 1))
  done

  wait "$hz_p" 2>/dev/null || true

  local scan_hz scan_n drive_hz drive_n
  if [ -f "$hz_json" ]; then
    scan_hz=$(python3 -c "import json; print(json.load(open('$hz_json'))['scan_hz'])")
    scan_n=$(python3 -c "import json; print(json.load(open('$hz_json'))['scan_n'])")
    drive_hz=$(python3 -c "import json; print(json.load(open('$hz_json'))['drive_hz'])")
    drive_n=$(python3 -c "import json; print(json.load(open('$hz_json'))['drive_n'])")
  else
    scan_hz=0; scan_n=0; drive_hz=0; drive_n=0
  fi
  echo "$w,/scan,$scan_hz,$scan_n"   >> "$THROUGHPUT_CSV"
  echo "$w,/drive,$drive_hz,$drive_n" >> "$THROUGHPUT_CSV"
}

for w in $(seq 1 "$N_WINDOWS"); do
  echo ""
  echo "================================================================="
  echo "  PERF $CONDITION  window $w / $N_WINDOWS  @ $(date +%H:%M:%S)"
  echo "================================================================="

  kill_all_procs

  if ! start_sim_and_driver; then
    echo "[window $w] sim+driver failed, skipping" >&2
    continue
  fi

  case "$CONDITION" in
    baseline) ;;
    monitor_only)
      start_monitor "$w"
      ;;
    monitor_defender)
      start_monitor "$w"
      start_defender "$w"
      ;;
    full)
      start_monitor "$w"
      start_defender "$w"
      start_attacker "$w"
      ;;
  esac

  sleep 3
  sample_window "$w"
done

kill_all_procs
echo ""
echo "============================================================="
echo "  PERF $CONDITION COMPLETE @ $(date)"
echo "  rows in samples.csv:   $(wc -l < "$SAMPLES_CSV")"
echo "  rows in throughput.csv: $(wc -l < "$THROUGHPUT_CSV")"
echo "============================================================="
