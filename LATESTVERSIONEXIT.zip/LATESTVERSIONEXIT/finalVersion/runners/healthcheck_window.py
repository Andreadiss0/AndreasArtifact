#!/usr/bin/env python3
"""Per-10-trial rolling health-window summary.

Reads <run_dir>/verification.csv, prints a table of the last N trial
verification rows, and writes the same table to
<run_dir>/health_window_<last_trial>.txt.

Exit code 0 on success, 1 if any trial in the window is unhealthy.
The clean_run.sh loop checks this exit code and emits a loud warning.

Usage:
    python3 healthcheck_window.py <run_dir> [window_size]
"""
from __future__ import annotations
import sys, os, csv

WINDOW = 10


def main():
    if len(sys.argv) < 2:
        sys.stderr.write("usage: healthcheck_window.py <run_dir> [window_size]\n")
        sys.exit(2)
    run_dir = sys.argv[1].rstrip("/")
    window = int(sys.argv[2]) if len(sys.argv) > 2 else WINDOW

    csv_path = os.path.join(run_dir, "verification.csv")
    if not os.path.exists(csv_path):
        sys.stderr.write(f"verification.csv not found at {csv_path}\n")
        sys.exit(2)

    with open(csv_path) as f:
        rows = list(csv.DictReader(f))

    if not rows:
        print("(no trials yet)")
        sys.exit(0)

    last = rows[-window:]
    last_trial_n = last[-1]["trial"]
    out_path = os.path.join(run_dir, f"health_window_{last_trial_n}.txt")

    lines = []
    lines.append(f"=== rolling health window (last {len(last)} trials in {os.path.basename(run_dir)}) ===")
    lines.append(f"  trial  | verdict                       | steps | scan_pub_first | scan_pub_last | zero/total          | healthy | reasons")
    lines.append(f"  -------|-------------------------------|-------|----------------|---------------|---------------------|---------|----------------")
    unhealthy_count = 0
    for r in last:
        t  = r["trial"]
        v  = r["verdict"]
        st = r["steps"]
        sf = r["scan_pub_first"]
        sl = r["scan_pub_last"]
        zo = r["scan_pub_zero_ticks"]
        tc = r["tick_count"]
        h  = "yes" if r["healthy"] == "1" else "NO"
        if h == "NO":
            unhealthy_count += 1
        rr = r["health_reasons"][:60]
        lines.append(f"  {t:>5}  | {v:<29} | {st:>5} | {sf:>14} | {sl:>13} | {zo:>9}/{tc:<9} | {h:>7} | {rr}")
    lines.append("")
    lines.append(f"  unhealthy trials in this window: {unhealthy_count} / {len(last)}")
    if unhealthy_count:
        lines.append("  ** WARNING: at least one trial in this window failed verification.")
        lines.append("     Inspect the trial(s) marked NO before trusting the aggregate.")

    txt = "\n".join(lines)
    print(txt)
    with open(out_path, "w") as f:
        f.write(txt + "\n")

    sys.exit(1 if unhealthy_count else 0)


if __name__ == "__main__":
    main()
