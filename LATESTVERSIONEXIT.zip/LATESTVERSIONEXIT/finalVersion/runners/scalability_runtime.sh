#!/bin/bash
# Usage: scalability_runtime.sh <level_dir> <trials>
#   level_dir: a directory under experiment_runs/scalability/ that must contain
#              AttackGraph.dot, test.prism, Strat.txt (the Mac-side outputs).
#   trials:    e.g. 30
#
# Per level: swap the three Mac-supplied files into the canonical paths used
# by attacker_agent_test.py / defender_agent.py, run clean_run.sh, and record
# (per-trial wall-clock, per-trial attacker steps, per-trial verdict). Aggregates
# to runtime_metrics.csv inside the level dir.

if [ "$#" -lt 2 ]; then
  echo "usage: $0 <level_dir> <trials>" >&2
  exit 2
fi

LEVEL_DIR="$1"
TRIALS="$2"
FV=/home/f1tenth/finalVersion

[ -d "$LEVEL_DIR" ] || { echo "no such level dir: $LEVEL_DIR" >&2; exit 2; }
for f in AttackGraph.dot test.prism Strat.txt; do
  [ -f "$LEVEL_DIR/$f" ] || { echo "missing $LEVEL_DIR/$f" >&2; exit 2; }
done

# Stash canonical files so we can restore at the end.
STASH="/tmp/scalability_stash_$$"
mkdir -p "$STASH"
cp "$FV/AttackGraph.dot" "$STASH/AttackGraph.dot.orig"
cp "$FV/test.prism"      "$STASH/test.prism.orig" 2>/dev/null || true
cp "$FV/Strat.txt"       "$STASH/Strat.txt.orig"

restore() {
  cp "$STASH/AttackGraph.dot.orig" "$FV/AttackGraph.dot" 2>/dev/null
  [ -f "$STASH/test.prism.orig" ] && cp "$STASH/test.prism.orig" "$FV/test.prism"
  cp "$STASH/Strat.txt.orig"       "$FV/Strat.txt"        2>/dev/null
  rm -rf "$STASH"
}
trap restore EXIT INT TERM

# Swap in the level's files.
cp "$LEVEL_DIR/AttackGraph.dot" "$FV/AttackGraph.dot"
cp "$LEVEL_DIR/test.prism"      "$FV/test.prism"
cp "$LEVEL_DIR/Strat.txt"       "$FV/Strat.txt"

LEVEL_NAME=$(basename "$LEVEL_DIR")
RUN_NAME="scalability_${LEVEL_NAME}"

T0=$(date +%s)
DISPLAY=:0 bash "$FV/runners/clean_run.sh" synth_vs_random "$TRIALS" 2>&1 | tee "$LEVEL_DIR/runtime.log"
T1=$(date +%s)

# Pull the resulting summary into the level dir.
if [ -f "$FV/experiment_runs/synth_vs_random/summary.csv" ]; then
  cp "$FV/experiment_runs/synth_vs_random/summary.csv" "$LEVEL_DIR/trial_summary.csv"
fi

# Aggregate runtime metrics.
python3 - "$LEVEL_DIR/trial_summary.csv" "$LEVEL_DIR/runtime_metrics.csv" $((T1 - T0)) <<'PYEOF'
import sys, csv, statistics
src, dst, wall = sys.argv[1], sys.argv[2], int(sys.argv[3])
try:
    with open(src) as f:
        rows = list(csv.DictReader(f))
except FileNotFoundError:
    rows = []
n = len(rows)
def col(name, cast=float):
    vals = []
    for r in rows:
        v = r.get(name, "")
        if v == "" or v is None: continue
        try: vals.append(cast(v))
        except ValueError: continue
    return vals
durations = col("trial_duration_sec")
steps = col("attacker_steps", int)
verdicts = [r.get("verdict","") for r in rows]
def mstd(vs):
    return f"{statistics.mean(vs):.2f}" + (f" ± {statistics.stdev(vs):.2f}" if len(vs) > 1 else "")
with open(dst, "w") as f:
    w = csv.writer(f)
    w.writerow(["metric","value"])
    w.writerow(["n_trials", n])
    w.writerow(["wall_clock_sec_total", wall])
    w.writerow(["trial_duration_mean_std", mstd(durations) if durations else "—"])
    w.writerow(["attacker_steps_mean_std", mstd(steps) if steps else "—"])
    w.writerow(["pmax_empirical", f"{sum(1 for v in verdicts if v=='ATTACKER_WIN')/n:.3f}" if n else "—"])
PYEOF

cat "$LEVEL_DIR/runtime_metrics.csv"
echo "level $LEVEL_NAME done"
