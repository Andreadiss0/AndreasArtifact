#!/usr/bin/env python3
# Roll up 3-treatment defender experiment.
# Inputs:  experiment/policy_<NAME>/trial_*/attacker.log + alerts.log + defender.log
# Output:  table to stdout — empirical Pmax, avg turns, per-attack det/mit.
#
# Usage: python3 experiment_aggregate.py <experiment-root>

import csv
import os
import re
import sys
from collections import defaultdict, Counter

ROOT = sys.argv[1] if len(sys.argv) > 1 else "/home/f1tenth/finalVersion/experiment"

# attack family -> expected REQ alert (parallel to _PRED_TO_EXPECTED_REQ in attacker)
ATTACK_TO_REQ = {
    "credentialAccess":         "REQ_credential_access",
    "attackerCanJoinRosGraph":  "REQ_can_join_ros_graph",
    "attackerCanNetAdmin":      "REQ_can_net_admin",
    "topicDrop":                "REQ_scan_unreliable",
    "topicDelay":               "REQ_scan_unreliable",
    "qosDegradation":           "REQ_scan_unreliable",
    "reliabilityFlip":          "REQ_scan_unreliable",
    "topicFlood":               "REQ_drive_DoS",
    "arrayDosExploit":          "REQ_drive_DoS",
    "maliciousTopicContent":    "REQ_scan_corrupted",
    "mitmInjection":            "REQ_scan_corrupted",
    "stalePublish":             "REQ_scan_corrupted",
    "gradualDrift":             "REQ_command_unsafe",
    "parameterTamper":          "REQ_bridge_misconfigured",
    "lifecycleHijack":          "REQ_map_server_down",
    "lifecycleAbuse":           "REQ_map_server_down",
    "cryptoInfoLeak":           "REQ_data_leaked",
    "crossTopicCorrelation":    "REQ_data_leaked",
    "topicRead":                "REQ_data_leaked",
    "exfiltrateChannel":        "REQ_data_leaked",
}

FIRED_RE = re.compile(r"ATTACKER\s+fired\s+([A-Za-z_]+)\s*\(")
REQ_RE   = re.compile(r"(REQ_[a-z_]+)")
DEF_RE   = re.compile(r"strategy says:\s*(def_[a-z_]+)")

VERDICTS = ("ATTACKER_WIN", "DEFENDER_WIN_GIVE_UP",
            "DEFENDER_WIN_COST_EXHAUSTED", "DEFENDER_WIN_TIMEOUT", "UNKNOWN")


def parse_trial(trial_dir):
    """Return per-trial dict: verdict, steps, alerts, defenses, attacks{fam:n},
    reqs{REQ:n}, defs{def:n}."""
    out = {"verdict": "UNKNOWN", "steps": 0, "alerts": 0, "defenses": 0,
           "attacks": Counter(), "reqs": Counter(), "defs": Counter()}
    attacker_log = os.path.join(trial_dir, "attacker.log")
    alerts_log   = os.path.join(trial_dir, "alerts.log")
    defender_log = os.path.join(trial_dir, "defender.log")
    try:
        with open(attacker_log) as f:
            txt = f.read()
    except FileNotFoundError:
        return out
    if "Attacker reached systemCompromised" in txt:
        out["verdict"] = "ATTACKER_WIN"
    elif "Attacker gave up" in txt:
        out["verdict"] = "DEFENDER_WIN_GIVE_UP"
    elif "Attacker cost budget exhausted" in txt:
        out["verdict"] = "DEFENDER_WIN_COST_EXHAUSTED"
    elif re.search(r"MAX_STEPS=.* reached without compromise", txt):
        out["verdict"] = "DEFENDER_WIN_TIMEOUT"
    out["steps"] = len(re.findall(r"========== ATTACK STEP", txt))
    for m in FIRED_RE.finditer(txt):
        out["attacks"][m.group(1)] += 1
    try:
        with open(alerts_log) as f:
            alerts_txt = f.read()
        out["alerts"] = len(re.findall(r"^\[1[0-9]+\.", alerts_txt, re.M))
        for m in REQ_RE.finditer(alerts_txt):
            out["reqs"][m.group(1)] += 1
    except FileNotFoundError:
        pass
    try:
        with open(defender_log) as f:
            d_txt = f.read()
        out["defenses"] = len(re.findall(r"strategy says:", d_txt))
        for m in DEF_RE.finditer(d_txt):
            out["defs"][m.group(1)] += 1
    except FileNotFoundError:
        pass
    return out


def summarise_policy(policy_root):
    """Return per-policy roll-up across all its trials."""
    trial_dirs = sorted(d for d in os.listdir(policy_root)
                        if d.startswith("trial_") and
                        os.path.isdir(os.path.join(policy_root, d)))
    trials = [parse_trial(os.path.join(policy_root, d)) for d in trial_dirs]
    n = len(trials)
    verdict_counts = Counter(t["verdict"] for t in trials)
    total_steps    = sum(t["steps"] for t in trials)
    total_alerts   = sum(t["alerts"] for t in trials)
    total_defenses = sum(t["defenses"] for t in trials)
    fam_attacks    = Counter()
    fam_alerts     = Counter()
    fam_defenses   = Counter()
    for t in trials:
        for fam, c in t["attacks"].items():
            fam_attacks[fam] += c
        # Pull alert family per trial: if expected REQ appeared at all,
        # count it once per matching attack fire in that trial (proxy
        # for "alert raised for this family").
        for fam in t["attacks"]:
            req = ATTACK_TO_REQ.get(fam)
            if req and t["reqs"].get(req, 0) > 0:
                fam_alerts[fam] += min(t["attacks"][fam], t["reqs"][req])
        # Mitigation proxy: number of defenses fired in trials where the
        # attack family appeared. Crude but consistent across policies.
        if t["defenses"] > 0:
            for fam, c in t["attacks"].items():
                fam_defenses[fam] += min(c, t["defenses"])
    return {
        "n": n,
        "verdicts": verdict_counts,
        "avg_steps": total_steps / n if n else 0,
        "avg_alerts": total_alerts / n if n else 0,
        "avg_defenses": total_defenses / n if n else 0,
        "fam_attacks": fam_attacks,
        "fam_alerts": fam_alerts,
        "fam_defenses": fam_defenses,
    }


def main():
    policies = []
    for p in sorted(os.listdir(ROOT)):
        if p.startswith("policy_") and os.path.isdir(os.path.join(ROOT, p)):
            policies.append(p[len("policy_"):])
    if not policies:
        print(f"No policy_* directories found in {ROOT}")
        return
    summaries = {p: summarise_policy(os.path.join(ROOT, f"policy_{p}"))
                 for p in policies}

    print()
    print("=" * 86)
    print(f"  DEFENDER-POLICY EXPERIMENT — {ROOT}")
    print("=" * 86)
    hdr = f"{'policy':>8}  {'n':>3}  {'Pmax':>6}  {'A_WIN':>5}  {'GIVE':>4}  {'COST':>4}  {'TO':>3}  {'steps':>6}  {'alerts':>7}  {'defs':>5}"
    print(hdr)
    print("-" * 86)
    for p in policies:
        s = summaries[p]
        n = s["n"]
        awin = s["verdicts"].get("ATTACKER_WIN", 0)
        give = s["verdicts"].get("DEFENDER_WIN_GIVE_UP", 0)
        cost = s["verdicts"].get("DEFENDER_WIN_COST_EXHAUSTED", 0)
        to   = s["verdicts"].get("DEFENDER_WIN_TIMEOUT", 0)
        pmax = awin / n if n else 0
        print(f"{p:>8}  {n:>3}  {pmax:>6.2f}  {awin:>5}  {give:>4}  {cost:>4}  "
              f"{to:>3}  {s['avg_steps']:>6.1f}  {s['avg_alerts']:>7.1f}  "
              f"{s['avg_defenses']:>5.1f}")
    print()
    print("PRISM-games predicted Pmax = 0.20 (synth coalition).")
    print()

    # Per-attack det/mit rates per policy
    print("=" * 86)
    print("  PER-ATTACK DETECTION & MITIGATION RATES")
    print("=" * 86)
    print("Detection = fraction of attack fires that produced the expected REQ alert.")
    print("Mitigation = fraction of attack fires that occurred in trials where a")
    print("             defense ran (proxy; defense<->attack temporal pairing not")
    print("             available from current logs).")
    print()
    all_fams = set()
    for s in summaries.values():
        all_fams.update(s["fam_attacks"].keys())
    if not all_fams:
        print("(no attacks fired in any trial)")
        return
    sub_hdr = f"{'attack family':>26}  " + "  ".join(
        f"{p[:8]:>8} det/mit" for p in policies)
    print(sub_hdr)
    print("-" * len(sub_hdr))
    for fam in sorted(all_fams):
        row = f"{fam:>26}  "
        for p in policies:
            s = summaries[p]
            a = s["fam_attacks"].get(fam, 0)
            al = s["fam_alerts"].get(fam, 0)
            df = s["fam_defenses"].get(fam, 0)
            det = al / a if a else 0
            mit = df / a if a else 0
            row += f"{det:>4.2f}/{mit:<4.2f}      " if a else f"{'-/-':>4}             "
        print(row)
    print()


if __name__ == "__main__":
    main()
